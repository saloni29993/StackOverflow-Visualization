var query = [
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"abstract classes\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"abstract classes\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"abstract classes\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"abstract classes\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"abstract classes\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"object overloading\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"object overloading\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"object overloading\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"object overloading\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"object overloading\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"object overloading\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"object overloading\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"object overloading\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"class\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"string\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"object overloading\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"abstract classes\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"subclass\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"/n two in a row\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"/n two in a row\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"bubble sort\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"bubble sort\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"bubble sort\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"bubble sort\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"bubble sort\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"bubble sort\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"bubble sort\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"bubble sort\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"bubble sort\n",
    "u_id":"A0082"
  },

  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"inheritance in object\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"inheritance in object\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"inheritance in object\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"inheritance in object\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"inheritance in object\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"inheritance in object\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"inheritance in object\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"inheritance in object\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"inheritance in object\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"inheritance in object\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"inheritance in object\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"inheritance in object\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"inheritance in object\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"inheritance in object\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"inheritance in object\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"inheritance in object\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"methods and object same?\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"methods and object same?\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"methods and object same?\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"methods and object same?\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"methods and object same?\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"methods and object same?\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"methods and object same?\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"methods and object same?\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"methods and object same?\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"methods and object same?\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"methods and object same?\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"sorting in java\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"/n sort\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441420000000,
    "intention":"PS",
    "query":"/n two in a row\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1440720000000,
    "intention":"ML",
    "query":"how to get main method\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1440720000000,
    "intention":"ML",
    "query":"how to get main method\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1440720000000,
    "intention":"ML",
    "query":"how to get main method\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1440720000000,
    "intention":"ML",
    "query":"how to get main method\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1440720000000,
    "intention":"ML",
    "query":"how to get main method\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1440740000000,
    "intention":"KS",
    "query":"new scanner (system.in)\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1440740000000,
    "intention":"NA",
    "query":"nextInt()\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1440740000000,
    "intention":"NA",
    "query":"do loop\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1440740000000,
    "intention":"NA",
    "query":"while-do loop\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1441270000000,
    "intention":"KS",
    "query":"what meaning of /n\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1441920000000,
    "intention":"KS",
    "query":"nextString\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1441940000000,
    "intention":"ML",
    "query":"how to converse case\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1441940000000,
    "intention":"NA",
    "query":"how to converse downcase to upcase\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1441940000000,
    "intention":"NA",
    "query":"how to converse down case to up case\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1441940000000,
    "intention":"NA",
    "query":"how to converse down case to up case\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1441940000000,
    "intention":"NA",
    "query":"how to converse down case to up case\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1441940000000,
    "intention":"NA",
    "query":"how to converse down case to up case\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1441940000000,
    "intention":"NA",
    "query":"how to converse down case to up case\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1441940000000,
    "intention":"NA",
    "query":"how to converse down case to up case\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1441940000000,
    "intention":"NA",
    "query":"how to converse down case to up case\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1441940000000,
    "intention":"NA",
    "query":"how to converse down case to up case\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1441940000000,
    "intention":"NA",
    "query":"how to converse down case to up case\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1441940000000,
    "intention":"NA",
    "query":"how to converse down case to up case\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1441940000000,
    "intention":"NA",
    "query":"how to use euqals to ignoring case\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"number format method\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1442630000000,
    "intention":"NA",
    "query":"use number format to string\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"simple sort\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"simple sort\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"simple sort\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"simple sort\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"simple sort\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"simple sort\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"simple sort\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"simple object overloading\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"simple object overloading\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"simple object overloading\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"simple object overloading\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"simple object overloading\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"simple object overloading\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"simple object overloading\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"simple object overloading\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"simple object overloading\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"simple object overloading\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"simple object overloading\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"difference between array and object\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"difference between array and object\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"difference between array and object\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"difference between array and object\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"difference between array and object\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"difference between array and object\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"difference between array and object\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"difference between array and object\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"difference between array and object\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"difference between array and object\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"difference between array and object\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"difference between array and object\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"difference between array and object\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"difference between array and object\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"simple sort\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"simple sort\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"simple sort\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"simple sort\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"sample\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1445020000000,
    "intention":"ML",
    "query":"JRadioButton\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1445020000000,
    "intention":"ML",
    "query":"how to transfer int to color\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1445020000000,
    "intention":"NA",
    "query":"how to transfer int to Color\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1445020000000,
    "intention":"ML",
    "query":"Color[]\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1448010000000,
    "intention":"ML",
    "query":"what method can decide character to operand \n",
    "u_id":"A0008"
  },
  {
    "timestamp":1448010000000,
    "intention":"NA",
    "query":"askto method\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1448010000000,
    "intention":"NA",
    "query":"ask to method\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1441330000000,
    "intention":"KS",
    "query":"How to call from other class\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1441330000000,
    "intention":"NA",
    "query":"How to call methods from other class\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1441380000000,
    "intention":"PS",
    "query":"call method from other class\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1441380000000,
    "intention":"NA",
    "query":"print method from other class\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1441380000000,
    "intention":"NA",
    "query":"call private method from other class\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1441380000000,
    "intention":"NA",
    "query":"print private value from other method\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1441380000000,
    "intention":"NA",
    "query":"print private value from other class\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"string parser\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442610000000,
    "intention":"NA",
    "query":"parser java\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442610000000,
    "intention":"PS",
    "query":"array\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"PS",
    "query":"read from object\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"PS",
    "query":"read from java\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"NA",
    "query":"read string from java\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"parseInteger\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"parseInteger\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"parseInteger\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"parseInteger\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"class duplication\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"class duplication\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"class duplication\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"class duplication\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"class duplication\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"class duplication\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"class duplication\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"class duplication\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"class duplication\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"polymorphism and inheritance difference\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"polymorphism and inheritance difference\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"polymorphism and inheritance difference\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"polymorphism and inheritance difference\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"polymorphism and inheritance difference\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"polymorphism and inheritance difference\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"polymorphism and inheritance difference\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"polymorphism and inheritance difference\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"polymorphism and inheritance difference\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"polymorphism and inheritance difference\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"polymorphism and inheritance difference\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"parseInteger\n",
    "u_id":"B0026"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"what is the length method\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"how do you know whats private or public\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"whats the symbol for private method\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1442620000000,
    "intention":"KS",
    "query":"how to create a subclass\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1442620000000,
    "intention":"NA",
    "query":"how to create a subclass in java\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1442630000000,
    "intention":"ML",
    "query":"how to write a toString\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"how to format decimals\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1442640000000,
    "intention":"KS",
    "query":"how to use java.text.DecimalFormat\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1442640000000,
    "intention":"NA",
    "query":"how to use java.text.DecimalFormat in a string\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"array initialization\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"array initialization\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"array initialization\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"array initialization\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"array initialization\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"array initialization\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"array initialization\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"array initialization\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"array initialization\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"array sorting\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"array sorting\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"array sorting\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"array sorting\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"array sorting\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"array sorting\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"array sorting\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"array sorting\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"array sorting\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"array sorting\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"array sorting\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"array sorting\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"how to create an enhanced for loop\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"how to create an enhanced for loop\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"how to create an enhanced for loop\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"how to create an enhanced for loop\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"how to create an enhanced for loop\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"how to create an enhanced for loop\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"how to create an enhanced for loop\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"how to create an enhanced for loop\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"how to create an enhanced for loop\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"how to create an enhanced for loop\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"how to create an enhanced for loop\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"how to create an enhanced for loop\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"how to create an enhanced for loop\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"how to create an enhanced for loop\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"how to create an enhanced for loop\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"how to create an enhanced for loop\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"how to create an object\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"how to create an object\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"how to create an object\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"how to create an object\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"how to create an object\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"how to create an object\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"how to create an enhanced for loop\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"how to create an enhanced for loop\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"how to create an enhanced for loop\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"array sorting\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"array sorting\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"array initialization\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"array initialization\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1441760000000,
    "intention":"KS",
    "query":"array initialization\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"initialize array list\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"initialize array list\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"initialize array list\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"initialize array list\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"initialize array list\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"initialize array list\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"initialize array list\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"initialize array list\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"initialize array list\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"string length checking\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"string length checking\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"string length checking\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"string length checking\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"string length checking\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"string length checking\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"string length checking\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"string length checking\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"string length checking\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"string length checking\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"string length checking\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"inheritance easy code\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"inheritance easy code\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"inheritance easy code\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"inheritance easy code\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"inheritance easy code\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"inheritance easy code\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"method creation and class easy code\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"method creation and class easy code\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"method creation and class easy code\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"method creation and class easy code\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"method creation and class easy code\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"method creation and class easy code\n",
    "u_id":"A0065"
  },

  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"method creation and class easy code\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"method creation and class easy code\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"method creation and class easy code\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"method creation and class easy code\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"method creation and class easy code\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1440750000000,
    "intention":"ML",
    "query":"method creation and class easy code\n",
    "u_id":"A0065"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"numbers in a array\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"sorting numbers in a array\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"sorting numbers\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"sorting numbers\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"sorting numbers\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"object creation\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"method\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"string conversion\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"string conversion\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"numbers in a array\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"sorting n\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"array\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"array\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"array\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"methods in java\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"methods in java\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"methods in java\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"methods in java\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"method in java\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"method in java\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"class inheritance in java\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"class inheritance in java\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"class inheritance in java\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"class inheritance in java\n",
    "u_id":"A0043"
  },

  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"class inheritance in java\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"class inheritance in java\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"class inheritance in java\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"class inheritance in java\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"class inheritance in java\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"class inheritance in java\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"class inheritance in java\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"class inheritance in java\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"array\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1442370000000,
    "intention":"PS",
    "query":"how to take of certain decimal places\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1442370000000,
    "intention":"NA",
    "query":"how to take off certain decimal places in java\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1442370000000,
    "intention":"NA",
    "query":"fixing decimal places in java\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1446070000000,
    "intention":"KS",
    "query":"Does .contains search through an entire array\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1446070000000,
    "intention":"NA",
    "query":"how to search through an entire array for an item\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1446070000000,
    "intention":"NA",
    "query":"how to search through an entire array for an item in java\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1446070000000,
    "intention":"NA",
    "query":"finding objects in an array\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1446160000000,
    "intention":"KS",
    "query":"how to check if an arraylist is empty\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1446160000000,
    "intention":"NA",
    "query":"how to return an array list from a different class\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1446240000000,
    "intention":"PS",
    "query":"selection sorting arraylists\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1446240000000,
    "intention":"NA",
    "query":"using comparator with arrays\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1446510000000,
    "intention":"PS",
    "query":"write a text (string) to the specified file\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1446510000000,
    "intention":"NA",
    "query":"java write a string to a specified file\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1446700000000,
    "intention":"NA",
    "query":"recursive counter\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1446700000000,
    "intention":"NA",
    "query":"how to count something in a recursive method java\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1446700000000,
    "intention":"NA",
    "query":"counting even values in an array recursively\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1446700000000,
    "intention":"NA",
    "query":"getting recursive methods to work in java\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1447200000000,
    "intention":"NA",
    "query":"counting the size of nodes in a linked list\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1447200000000,
    "intention":"NA",
    "query":"counting the size of nodes in a linked list java\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1447200000000,
    "intention":"NA",
    "query":"counting the number of nodes in a linked list java\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1447200000000,
    "intention":"NA",
    "query":"counting the number of nodes in a linked list java\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"\t\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"string",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"string",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"string",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"string",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"string",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"string",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"string",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"string",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"string",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"string",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"string",
    "u_id":"A0019"
  },

  {
    "timestamp":1442630000000,
    "intention":"NA",
    "query":"\t\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"inheritance\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"inheritance\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"inheritance\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"inheritance\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"inheritance\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"inheritance\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"inheritance\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"inheritance\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"inheritance class\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"inheritance class\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"inheritance class\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"inheritance class\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"inheritance class\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"inheritance class\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"inheritance class\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"inheritance class\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"inheritance class\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"how to implement loop for array\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"how to implement loop for array\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"how to implement loop\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"how to implement loop\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"array length function\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"array length function\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"array length function\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"array length function\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"array length function\n",
    "u_id":"A0019"
  },

  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"how to implement loop for array\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"how to implement loop for array\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"array length function\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"how to implement loop for array\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"how to implement loop for array\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"inheritance class\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"inheritance class\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"how to implement loop for array\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"abstract classes\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"NA",
    "query":"implementing abstract classes\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"parsing a string\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1442630000000,
    "intention":"KS",
    "query":"java split funtion\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1444010000000,
    "intention":"KS",
    "query":"panels\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1444010000000,
    "intention":"KS",
    "query":"vector\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1444010000000,
    "intention":"NA",
    "query":"vector java\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1444010000000,
    "intention":"KS",
    "query":"what is a vector\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1444020000000,
    "intention":"KS",
    "query":"buttonlistener class\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1444120000000,
    "intention":"PS",
    "query":"new line with setText java\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"get and set methods\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"merge arraylist\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1447370000000,
    "intention":"KS",
    "query":"how to get size of linkedlist\n",
    "u_id":"A0019"
  },
  {
    "timestamp":1440750000000,
    "intention":"PS",
    "query":"scanner never closes\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"KS",
    "query":"how to use variable from another method\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"KS",
    "query":"Calling a function and getting value from variable in that method\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"Calling a function \n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"Calling a function java\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"displaying variables from other method java\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"displaying variables from other method java\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"displaying variables from other method java\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"displaying variables from other method java\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"inheritance handling\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"inheritance handling\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"inheritance handling\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"inheritance handling\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"inheritance handling\n",
    "u_id":"A0080"
  },

  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"inheritance handling\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"inheritance handling\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"inheritance handling\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"inheritance handling\n",
    "u_id":"A0080"
  },

  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"displaying variables from other method java\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"displaying variables from other method java\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"displaying variables from other method java\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"inheritance handling\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"displaying variables from other method java\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"displaying variables from other function\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"can an object be null?\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"can an object be null?\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"can an object be null?\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"can an object be null?\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"can an object be null?\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"can an object be null?\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"displaying variables from other method java\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "intention":"NA",
    "query":"how to get more than one input\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440780000000,
    "intention":"KS",
    "query":"passing variables to main method\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440780000000,
    "intention":"NA",
    "query":"passing variables to main method java\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1441260000000,
    "intention":"KS",
    "query":"how to use stringto()\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1441260000000,
    "intention":"NA",
    "query":"how to use toString()\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1441260000000,
    "intention":"NA",
    "query":"toString\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1441260000000,
    "intention":"NA",
    "query":"toString\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1441260000000,
    "intention":"NA",
    "query":"toString() java\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1442430000000,
    "intention":"KS",
    "query":"lineToParse\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1442430000000,
    "intention":"NA",
    "query":"lineToParse java\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"merge sort examples java\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"merge sort examples  arraylisr java\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"merge sort arraylist java\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"read number sequence from console\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"read number sequence from console java\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440730000000,
    "intention":"KS",
    "query":"why do we need static modifier?\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1441070000000,
    "intention":"KS",
    "query":"why do we need static functions\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1441080000000,
    "intention":"NA",
    "query":"java static method\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1441390000000,
    "intention":"PS",
    "query":"constructors java\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"tostring\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1441390000000,
    "intention":"NA",
    "query":"tostring java\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1441400000000,
    "intention":"KS",
    "query":"super keyword java\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1442370000000,
    "intention":"KS",
    "query":"protected keyword\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1442910000000,
    "intention":"KS",
    "query":"type conversions\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1442910000000,
    "intention":"NA",
    "query":"loops in java\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1442910000000,
    "intention":"NA",
    "query":"type conversions java int double string\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1442910000000,
    "intention":"NA",
    "query":"inheritance in java\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1442910000000,
    "intention":"NA",
    "query":"inheritance in java\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1442910000000,
    "intention":"NA",
    "query":"inheritance in java\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1442910000000,
    "intention":"NA",
    "query":"inheritance in java\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1442910000000,
    "intention":"NA",
    "query":"inheritance in java\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1442910000000,
    "intention":"NA",
    "query":"inheritance in java\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1442910000000,
    "intention":"NA",
    "query":"inheritance in java\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1442910000000,
    "intention":"NA",
    "query":"inheritance in java\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1442910000000,
    "intention":"NA",
    "query":"inheritance in java\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1442910000000,
    "intention":"NA",
    "query":"loops in java\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1442910000000,
    "intention":"NA",
    "query":"loops in java\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1442910000000,
    "intention":"NA",
    "query":"loops in java\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1442910000000,
    "intention":"NA",
    "query":"loops in java\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1442910000000,
    "intention":"NA",
    "query":"loops in java\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1442910000000,
    "intention":"NA",
    "query":"loops in java\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1442910000000,
    "intention":"NA",
    "query":"loops in java\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1442910000000,
    "intention":"NA",
    "query":"loops in java\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1442910000000,
    "intention":"NA",
    "query":"loops in java\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1442910000000,
    "intention":"NA",
    "query":"loops in java\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1442910000000,
    "intention":"KS",
    "query":"transform double into string\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1442910000000,
    "intention":"KS",
    "query":"generic data types java\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"jradiobutton default selection\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"return method function\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"return method function java\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"merge and sort\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"merge and sort numbers\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"merge and sort array numbers java\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"3 parting merge sort\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"merge sort\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"3 partitin merge sort\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"long string works with objects?\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"long string works with objects?\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"long string works with objects?\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"long string works with objects?\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"long string works with objects?\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"long string works with objects?\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"long string works with objects?\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"long string works with objects?\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"object works with inheritance??\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"object works with inheritance??\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"object works with inheritance??\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"object works with inheritance??\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"object works with inheritance??\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"object works with inheritance??\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"object works with inheritance??\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"object works with inheritance??\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"object works with inheritance??\n",
    "u_id":"A0018"
  },

  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"object works with inheritance??\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"object works with inheritance??\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"enhanced for loop working\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"enhanced for loop working\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"enhanced for loop working\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"enhanced for loop working\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"enhanced for loop working\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"long string works with objects?\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"3 partition merge sort\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1444950000000,
    "intention":"ML",
    "query":"3-partition merge sort\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1440550000000,
    "intention":"ML",
    "query":"for loops\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444090000000,
    "intention":"ML",
    "query":"gridbag layout\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444840000000,
    "intention":"KS",
    "query":"adding object to array\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444840000000,
    "intention":"KS",
    "query":"adding object to array\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444840000000,
    "intention":"KS",
    "query":"adding object to array\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444840000000,
    "intention":"KS",
    "query":"adding object to array\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444840000000,
    "intention":"KS",
    "query":"adding object to array\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444840000000,
    "intention":"KS",
    "query":"adding object to array\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444840000000,
    "intention":"KS",
    "query":"adding loop to array\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444840000000,
    "intention":"KS",
    "query":"adding loop to array\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444840000000,
    "intention":"KS",
    "query":"adding loop to array\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444840000000,
    "intention":"KS",
    "query":"adding loop to array\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444840000000,
    "intention":"KS",
    "query":"adding loop to array\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444840000000,
    "intention":"KS",
    "query":"adding loop to array\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444840000000,
    "intention":"KS",
    "query":"adding loop to array\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444840000000,
    "intention":"KS",
    "query":"adding object to array\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444840000000,
    "intention":"KS",
    "query":"adding object to array\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444840000000,
    "intention":"KS",
    "query":"adding object to array\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444840000000,
    "intention":"NA",
    "query":"adding to array\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444840000000,
    "intention":"NA",
    "query":"color\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444840000000,
    "intention":"NA",
    "query":"color black\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444840000000,
    "intention":"NA",
    "query":"java color code\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444870000000,
    "intention":"KS",
    "query":"button group\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"2 partition merge sort\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"2 partition merge sort\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"ordered number array\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"ordered number array java\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444950000000,
    "intention":"ML",
    "query":"order numbers in an array\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444960000000,
    "intention":"ML",
    "query":"merge array list\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444960000000,
    "intention":"ML",
    "query":"3-partition merge sort\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1440730000000,
    "intention":"PS",
    "query":"covert string to int array in java\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1440730000000,
    "intention":"PS",
    "query":"covert string to int array in java\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1440730000000,
    "intention":"PS",
    "query":"covert string to int array in java\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1440730000000,
    "intention":"PS",
    "query":"covert string to int array in java\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1440720000000,
    "intention":"PS",
    "query":"java string to array\n",
    "u_id":"A0064"
  },
  {
    "timestamp":1440730000000,
    "intention":"PS",
    "query":"covert string to int array in java\n",
    "u_id":"A0064"
  },
  {
    "timestamp":1440730000000,
    "intention":"PS",
    "query":"read string into array in java\n",
    "u_id":"A0064"
  },
  {
    "timestamp":1440730000000,
    "intention":"NA",
    "query":"java convert string array to int array\n",
    "u_id":"A0064"
  },
  {
    "timestamp":1440730000000,
    "intention":"NA",
    "query":"how to read string with both positive and negative integers into array\n",
    "u_id":"A0064"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"merge sort\n",
    "u_id":"A0064"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"merge arrays to sorted result\n",
    "u_id":"A0064"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"merge arrays to sorted result java\n",
    "u_id":"A0064"
  },
  {
    "timestamp":1444960000000,
    "intention":"PS",
    "query":"merge sort trivial case java\n",
    "u_id":"A0064"
  },
  {
    "timestamp":1440720000000,
    "intention":"KS",
    "query":"java classes\n",
    "u_id":"A0052"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"3 partition merge sort\n",
    "u_id":"A0052"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"3 partition merge sort of array list\n",
    "u_id":"A0052"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"implementation of 3 part merge sort\n",
    "u_id":"A0052"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"implementation of 3 partition merge sort\n",
    "u_id":"A0052"
  },
  {
    "timestamp":1445140000000,
    "intention":"KS",
    "query":"throwing an exception\n",
    "u_id":"A0052"
  },
  {
    "timestamp":1445140000000,
    "intention":"KS",
    "query":"throwing an exception java\n",
    "u_id":"A0052"
  },
  {
    "timestamp":1445140000000,
    "intention":"KS",
    "query":"what is throwing an exception java?\n",
    "u_id":"A0052"
  },
  {
    "timestamp":1447290000000,
    "intention":"KS",
    "query":"compareTo linkedlists\n",
    "u_id":"A0052"
  },
  
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"enhanced for loop\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"enhanced for loop\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"enhanced for loop\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"enhanced for loop\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"java enhanced for loop\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440780000000,
    "intention":"KS",
    "query":"java enhanced for loop\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440780000000,
    "intention":"KS",
    "query":"java static modifier\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440780000000,
    "intention":"KS",
    "query":"java arraylist\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440780000000,
    "intention":"KS",
    "query":"java netbeans javadoc generation\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440970000000,
    "intention":"KS",
    "query":"python best ide\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441000000000,
    "intention":"KS",
    "query":"java inheritance constuctor\n",
    "u_id":"A0074"
  },
{
    "timestamp":1441000000000,
    "intention":"KS",
    "query":"java inheritance constuctor\n",
    "u_id":"A0098"
  },
  {
    "timestamp":1441000000000,
    "intention":"KS",
    "query":"java inheritance constuctor\n",
    "u_id":"A0098"
  },
  {
    "timestamp":1441000000000,
    "intention":"KS",
    "query":"java inheritance constuctor\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441000000000,
    "intention":"KS",
    "query":"java inheritance constuctor\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441000000000,
    "intention":"KS",
    "query":"java inheritance constuctor\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441000000000,
    "intention":"KS",
    "query":"java inheritance constuctor\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441000000000,
    "intention":"KS",
    "query":"java inheritance constuctor\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441000000000,
    "intention":"KS",
    "query":"java inheritance constuctor\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441000000000,
    "intention":"KS",
    "query":"java using constructor in another class\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441000000000,
    "intention":"KS",
    "query":"java access default constructor\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441000000000,
    "intention":"KS",
    "query":"java access default constructor from another class\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441000000000,
    "intention":"KS",
    "query":"java dot operations\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441000000000,
    "intention":"KS",
    "query":"java new objects\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441000000000,
    "intention":"KS",
    "query":"java create new objects\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441090000000,
    "intention":"KS",
    "query":"r convert probability to z \n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441350000000,
    "intention":"KS",
    "query":"command prompt\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441350000000,
    "intention":"KS",
    "query":"java automate input read\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441350000000,
    "intention":"KS",
    "query":"java bat files\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441350000000,
    "intention":"KS",
    "query":"java javac.exe\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441400000000,
    "intention":"KS",
    "query":"java change dir\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441400000000,
    "intention":"KS",
    "query":"java netbean change dir\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1442210000000,
    "intention":"KS",
    "query":"java google api\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1442210000000,
    "intention":"KS",
    "query":"java store web to txt\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1442210000000,
    "intention":"KS",
    "query":"java save web to txt\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1442210000000,
    "intention":"KS",
    "query":"java extract information from web\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1442210000000,
    "intention":"KS",
    "query":"java combobox\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1442550000000,
    "intention":"KS",
    "query":"java super\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1442550000000,
    "intention":"KS",
    "query":"java abstract\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1442560000000,
    "intention":"KS",
    "query":"java this\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1442560000000,
    "intention":"KS",
    "query":"java malform exception\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1442560000000,
    "intention":"NA",
    "query":"java malformexception\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1442560000000,
    "intention":"KS",
    "query":"java polumorphism\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1442560000000,
    "intention":"KS",
    "query":"java polymorphism\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1442560000000,
    "intention":"KS",
    "query":"java number format\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1442790000000,
    "intention":"KS",
    "query":"java enhance for loop\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1442790000000,
    "intention":"KS",
    "query":"java array initialization\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1442790000000,
    "intention":"NA",
    "query":"java array\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1442790000000,
    "intention":"KS",
    "query":"java polymorphism\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444100000000,
    "intention":"KS",
    "query":"button listener\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444130000000,
    "intention":"KS",
    "query":"java vector\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444870000000,
    "intention":"KS",
    "query":"insert element into array java\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444870000000,
    "intention":"KS",
    "query":"java color class\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444870000000,
    "intention":"KS",
    "query":"java Radio Buttons\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444880000000,
    "intention":"KS",
    "query":"java swtich\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"merge sort\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"increasing sort\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"merge sort\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"object creation\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"object creation\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"object creation\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"object creation\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"object creation\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"object creation\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"object creation\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"method creation\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"method creation\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"method creation\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"method creation\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"method creation\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"method creation\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"method creation\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"method creation\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"object creation\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"object creation\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"object creation\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"object creation\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445490000000,
    "intention":"KS",
    "query":"merge sort divided in 3\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445620000000,
    "intention":"KS",
    "query":"netbeans run applet\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1446320000000,
    "intention":"KS",
    "query":"compare stringd\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1446320000000,
    "intention":"KS",
    "query":"compare strings\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1446320000000,
    "intention":"KS",
    "query":"java compare string alphabetically\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1446440000000,
    "intention":"KS",
    "query":"java recursive find min\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1446440000000,
    "intention":"KS",
    "query":"insertion sort java\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1446450000000,
    "intention":"KS",
    "query":"sort comparator\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1446800000000,
    "intention":"KS",
    "query":"solve recursive\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1447120000000,
    "intention":"KS",
    "query":"java access node linkedlist\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1447400000000,
    "intention":"KS",
    "query":"java remove element at index\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1448000000000,
    "intention":"KS",
    "query":"stack\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1443120000000,
    "intention":"KS",
    "query":"wrapper classes\n",
    "u_id":"A0001"
  },
  {
    "timestamp":1443130000000,
    "intention":"NA",
    "query":"cast\n",
    "u_id":"A0001"
  },
  {
    "timestamp":1443130000000,
    "intention":"NA",
    "query":"cast java\n",
    "u_id":"A0001"
  },
  {
    "timestamp":1443130000000,
    "intention":"NA",
    "query":"implements keyword java\n",
    "u_id":"A0001"
  },
  {
    "timestamp":1444180000000,
    "intention":"NA",
    "query":"how to handle button events\n",
    "u_id":"A0001"
  },
  {
    "timestamp":1444180000000,
    "intention":"NA",
    "query":"button events using try catch block\n",
    "u_id":"A0001"
  },
  {
    "timestamp":1444180000000,
    "intention":"NA",
    "query":"java button events using try catch block\n",
    "u_id":"A0001"
  },
  {
    "timestamp":1445020000000,
    "intention":"ML",
    "query":"point listeners java\n",
    "u_id":"A0001"
  },
  {
    "timestamp":1445540000000,
    "intention":"KS",
    "query":"common gui components from javax.swing & java.awt packages\n",
    "u_id":"A0001"
  },
  {
    "timestamp":1445540000000,
    "intention":"NA",
    "query":"javax.swing basic components\n",
    "u_id":"A0001"
  },
  {
    "timestamp":1445540000000,
    "intention":"NA",
    "query":"error handling java\n",
    "u_id":"A0001"
  },
  {
    "timestamp":1448040000000,
    "intention":"KS",
    "query":"stacks java\n",
    "u_id":"A0001"
  },
  {
    "timestamp":1448070000000,
    "intention":"KS",
    "query":"infix to postfix\n",
    "u_id":"A0001"
  },
  {
    "timestamp":1448070000000,
    "intention":"NA",
    "query":"infix to postfix java\n",
    "u_id":"A0001"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"3-partition merge sort\n",
    "u_id":"A0057"
  },
  {
    "timestamp":1444960000000,
    "intention":"KS",
    "query":"partition input array\n",
    "u_id":"A0057"
  },
  {
    "timestamp":1440550000000,
    "intention":"KS",
    "query":"java for loop syntax\n",
    "u_id":"A0073"
  },
  {
    "timestamp":1442360000000,
    "intention":"KS",
    "query":"abstract class\n",
    "u_id":"A0073"
  },
  {
    "timestamp":1442600000000,
    "intention":"KS",
    "query":"where do you import Number format class from\n",
    "u_id":"A0073"
  },
  {
    "timestamp":1442610000000,
    "intention":"KS",
    "query":"parse\n",
    "u_id":"A0073"
  },
  {
    "timestamp":1442610000000,
    "intention":"ML",
    "query":"parse in java\n",
    "u_id":"A0073"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"3 partition merge sort\n",
    "u_id":"A0073"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"get ith term in arraylist\n",
    "u_id":"A0073"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"get i term in arraylist\n",
    "u_id":"A0073"
  },
  {
    "timestamp":1445000000000,
    "intention":"KS",
    "query":"different types of layouts in java\n",
    "u_id":"A0073"
  },
  {
    "timestamp":1445000000000,
    "intention":"ML",
    "query":"jsplitpane\n",
    "u_id":"A0073"
  },
  {
    "timestamp":1445950000000,
    "intention":"KS",
    "query":"serializable interface\n",
    "u_id":"A0073"
  },
  {
    "timestamp":1441320000000,
    "intention":"KS",
    "query":"multiple classes in java\n",
    "u_id":"A0040"
  },
  {
    "timestamp":1445040000000,
    "intention":"ML",
    "query":"how to sort by divide and conquer\n",
    "u_id":"A0040"
  },
  {
    "timestamp":1445040000000,
    "intention":"KS",
    "query":"what are alternatives to eclipse java\n",
    "u_id":"A0040"
  },
  {
    "timestamp":1445040000000,
    "intention":"KS",
    "query":"recursive sorting algorithms\n",
    "u_id":"A0040"
  },
  {
    "timestamp":1445530000000,
    "intention":"KS",
    "query":"subString\n",
    "u_id":"A0037"
  },
  {
    "timestamp":1445530000000,
    "intention":"KS",
    "query":"subString\n",
    "u_id":"A0037"
  },
  {
    "timestamp":1445530000000,
    "intention":"ML",
    "query":"substring\n",
    "u_id":"A0037"
  },
  {
    "timestamp":1446770000000,
    "intention":"KS",
    "query":"How do I make an array?\n",
    "u_id":"A0034"
  },
  {
    "timestamp":1447800000000,
    "intention":"KS",
    "query":"find minimum\n",
    "u_id":"A0034"
  },
  {
    "timestamp":1447800000000,
    "intention":"NA",
    "query":"find minimum integer\n",
    "u_id":"A0034"
  },
  {
    "timestamp":1440720000000,
    "intention":"KS",
    "query":"thenewboston\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1443060000000,
    "intention":"PS",
    "query":"result += 4 - j\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1443060000000,
    "intention":"NA",
    "query":"what does += do\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1443060000000,
    "intention":"NA",
    "query":"+=\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1443070000000,
    "intention":"KS",
    "query":"rectangle class\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1443070000000,
    "intention":"KS",
    "query":"rectangle arguments\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1443120000000,
    "intention":"PS",
    "query":"printing an array in MIPS\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1443160000000,
    "intention":"ML",
    "query":"how to check if there is overflow in MIPS\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1443160000000,
    "intention":"ML",
    "query":"overflow in MIPS\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1443210000000,
    "intention":"KS",
    "query":"how does MARS store data\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1443480000000,
    "intention":"ML",
    "query":"implementing borderlayout\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1443590000000,
    "intention":"ML",
    "query":"UpdateUI\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1444600000000,
    "intention":"ML",
    "query":"initializing a Color object\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1444600000000,
    "intention":"ML",
    "query":"initializing a Color object\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1444600000000,
    "intention":"ML",
    "query":"initializing a Color object\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1444600000000,
    "intention":"ML",
    "query":"initializing a Color object\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1444600000000,
    "intention":"ML",
    "query":"initializing a Color object\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1444600000000,
    "intention":"ML",
    "query":"initializing a Color object\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1444600000000,
    "intention":"NA",
    "query":"initializing a Color object in java\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1444600000000,
    "intention":"NA",
    "query":"Color \n",
    "u_id":"A0061"
  },
  {
    "timestamp":1444600000000,
    "intention":"NA",
    "query":"Color object in java\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"Mergesort\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1444960000000,
    "intention":"PS",
    "query":"splitting an array\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1444960000000,
    "intention":"NA",
    "query":"splitting an array java\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1444950000000,
    "intention":"ML",
    "query":"merge sort \n",
    "u_id":"A0024"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"3-partition merge sort\n",
    "u_id":"A0024"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":" merge sort\n",
    "u_id":"A0024"
  },
  {
    "timestamp":1444950000000,
    "intention":"ML",
    "query":"swap\n",
    "u_id":"A0024"
  },
  {
    "timestamp":1444950000000,
    "intention":"ML",
    "query":"swap java\n",
    "u_id":"A0024"
  },
  {
    "timestamp":1444950000000,
    "intention":"ML",
    "query":"swapping arrays in an arraylist\n",
    "u_id":"A0024"
  },
  {
    "timestamp":1444950000000,
    "intention":"ML",
    "query":"how to empty an array\n",
    "u_id":"A0024"
  },
  {
    "timestamp":1444950000000,
    "intention":"ML",
    "query":"clearing array\n",
    "u_id":"A0024"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"clearing array method java\n",
    "u_id":"A0024"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"emptying array method java\n",
    "u_id":"A0024"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"how to empty array method java\n",
    "u_id":"A0024"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"how to empty array  java\n",
    "u_id":"A0024"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"constructor methods\n",
    "u_id":"A0024"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"object constructor\n",
    "u_id":"A0024"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"object constructor\n",
    "u_id":"A0024"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"object constructor\n",
    "u_id":"A0024"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"object constructor\n",
    "u_id":"A0024"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"object constructor\n",
    "u_id":"A0024"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"object constructor\n",
    "u_id":"A0024"
  },
  {
    "timestamp":1442000000000,
    "intention":"ML",
    "query":"convert string to int\n",
    "u_id":"A0044"
  },
  {
    "timestamp":1442430000000,
    "intention":"KS",
    "query":"bufferedreader vs scanner\n",
    "u_id":"A0044"
  },
  {
    "timestamp":1442440000000,
    "intention":"PS",
    "query":"nullpointerexception arraylist\n",
    "u_id":"A0044"
  },
  {
    "timestamp":1442970000000,
    "intention":"KS",
    "query":"convert string to int\n",
    "u_id":"A0044"
  },
  {
    "timestamp":1444960000000,
    "intention":"KS",
    "query":"merge sort\n",
    "u_id":"A0044"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"sample\n",
    "u_id":"A0042"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"partition\n",
    "u_id":"A0042"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"partition merge sor\n",
    "u_id":"A0042"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"partition merge sort\n",
    "u_id":"A0042"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"merge sort\n",
    "u_id":"A0042"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"merge sort\n",
    "u_id":"A0042"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"sort 3 arrays\n",
    "u_id":"A0042"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"sort then merge\n",
    "u_id":"A0042"
  },
  {
    "timestamp":1440810000000,
    "intention":"KS",
    "query":"do-while\n",
    "u_id":"B0025"
  },
  {
    "timestamp":1440810000000,
    "intention":"ML",
    "query":"finding the max integer \n",
    "u_id":"B0025"
  },
  {
    "timestamp":1440810000000,
    "intention":"NA",
    "query":"finding the max integer in java\n",
    "u_id":"B0025"
  },
  {
    "timestamp":1441420000000,
    "intention":"ML",
    "query":"encapsulation\n",
    "u_id":"B0025"
  },
  {
    "timestamp":1441420000000,
    "intention":"ML",
    "query":"mutating a class\n",
    "u_id":"B0025"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"merge sort\n",
    "u_id":"A0081"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"assign new value to arraylist \n",
    "u_id":"A0081"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"merge sort using arraylist\n",
    "u_id":"A0081"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"switch values in arraylist size 2\n",
    "u_id":"A0081"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"Switch values in arraylist\n",
    "u_id":"A0081"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"Switch values in arraylist\n",
    "u_id":"A0081"
  },
  {
    "timestamp":1444950000000,
    "intention":"ML",
    "query":"switch values in arraylist \n",
    "u_id":"A0081"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"switch values in arraylist\n",
    "u_id":"A0081"
  },
  {
    "timestamp":1440650000000,
    "intention":"KS",
    "query":"find the minimum integer\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1441920000000,
    "intention":"KS",
    "query":"how to define '#'\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1441920000000,
    "intention":"NA",
    "query":"how to define '#'\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1442350000000,
    "intention":"KS",
    "query":"public static Product parseStringToProduct(String lineToParse)\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1442350000000,
    "intention":"KS",
    "query":"public static Product parseStringToProduct(String lineToParse)\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1442350000000,
    "intention":"NA",
    "query":"public static Product parseStringToProduct\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1442350000000,
    "intention":"NA",
    "query":"Product parseStringToProduct\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1442350000000,
    "intention":"KS",
    "query":"protect\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1443820000000,
    "intention":"KS",
    "query":"Container container = getContentPane()\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1443820000000,
    "intention":"KS",
    "query":"private Container getContentPane() {\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1444960000000,
    "intention":"KS",
    "query":"3 partition merge sort\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1444960000000,
    "intention":"NA",
    "query":" merge sort\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1445040000000,
    "intention":"KS",
    "query":"clear();\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1445040000000,
    "intention":"NA",
    "query":"clear(); java\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1446580000000,
    "intention":"PS",
    "query":"how to find evenIndex number in an array\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1446580000000,
    "intention":"KS",
    "query":"how to find evenIndex number in an array\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1446580000000,
    "intention":"NA",
    "query":"how to find even Index \n",
    "u_id":"A0009"
  },
  {
    "timestamp":1447360000000,
    "intention":"PS",
    "query":"counthowmany object\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1447360000000,
    "intention":"NA",
    "query":"counthowmany\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1447360000000,
    "intention":"NA",
    "query":"countHowMany(Object searchedObject)countHowMany(Object searchedObject)\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1447360000000,
    "intention":"NA",
    "query":"countHowMany(Object searchedObject)\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1447360000000,
    "intention":"NA",
    "query":"countHowMany(Object)\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1447360000000,
    "intention":"NA",
    "query":"removeDuplicate() method\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1441410000000,
    "intention":"PS",
    "query":"What is null pointer exception in java?\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1441410000000,
    "intention":"PS",
    "query":"inheritance?\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1441410000000,
    "intention":"PS",
    "query":"inheritance?\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1441410000000,
    "intention":"PS",
    "query":"inheritance?\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1441410000000,
    "intention":"PS",
    "query":"inheritance?\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1441410000000,
    "intention":"PS",
    "query":"inheritance?\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1441410000000,
    "intention":"PS",
    "query":"inheritance?\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1441410000000,
    "intention":"PS",
    "query":"converting double to string\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1442560000000,
    "intention":"PS",
    "query":"string in java\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1442560000000,
    "intention":"PS",
    "query":"string in java\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1442560000000,
    "intention":"PS",
    "query":"string in java\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1442560000000,
    "intention":"PS",
    "query":"string in java\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1442560000000,
    "intention":"PS",
    "query":"string in java\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1443660000000,
    "intention":"KS",
    "query":"vector class in java\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1443940000000,
    "intention":"KS",
    "query":"making labels bold\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1443940000000,
    "intention":"NA",
    "query":"making jlabels bold\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"abstract method\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"abstract method\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"abstract method\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"abstract method\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"abstract method\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"abstract method\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"abstract method\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"object overriding\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"object overriding\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"object overriding\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"object overriding\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"object overriding\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"class overriding\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"class overriding\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"class overriding\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"class overriding\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"class overriding\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"class overriding\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"class overriding\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"class overriding\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"class overriding and array declaration\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"class overriding and array declaration\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"array declaration\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"array declaration\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"array declaration\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"array declaration\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"array declaration\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"array declaration\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"array declaration\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"array declaration\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"array declaration\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"array declaration\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"array declaration\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"array declaration\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"merge sort in java\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"merge sort in java\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"merge sort in java\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"merge sort in java\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"merge sort in java\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"merge sort in java\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"merge sort in java\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"merge sort in java\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"merge sort in java\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"merge sort in java\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"merge sort in java\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"merge sort in java\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"array declaration\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"array declaration\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"class overriding and array declaration\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"class overriding and array declaration\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"class overriding\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"class overriding\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"class overriding\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444700000000,
    "intention":"NA",
    "query":"object overriding\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"inheritance method\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"inheritance method\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"inheritance method\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"inheritance method\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"inheritance\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"object method\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"object\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"inheritance\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"writing a to string method\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1441390000000,
    "intention":"NA",
    "query":"how to write a toString method\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1441390000000,
    "intention":"KS",
    "query":"how do I import a class\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1441390000000,
    "intention":"PS",
    "query":"cannot make a static reference to non-static reference\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1441390000000,
    "intention":"NA",
    "query":"how to write a mutator method\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1441850000000,
    "intention":"KS",
    "query":"writing a mutator method\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1441850000000,
    "intention":"NA",
    "query":"how do i make an overloaded mutator method\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1441850000000,
    "intention":"NA",
    "query":"overloaded mutator method\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1441850000000,
    "intention":"NA",
    "query":"inherit from abstract parent class\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1441850000000,
    "intention":"NA",
    "query":"subclass\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1441850000000,
    "intention":"NA",
    "query":"abstract classs\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1441850000000,
    "intention":"NA",
    "query":"abstract class\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1441850000000,
    "intention":"NA",
    "query":"how to set a variable in an abstract class using an overloaded constructor\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1442020000000,
    "intention":"NA",
    "query":"argument\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1442020000000,
    "intention":"NA",
    "query":"parse\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1442020000000,
    "intention":"NA",
    "query":"java parse string\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1442020000000,
    "intention":"NA",
    "query":"parser method\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1442020000000,
    "intention":"NA",
    "query":"parser method java\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1442020000000,
    "intention":"NA",
    "query":"utility class\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1442380000000,
    "intention":"KS",
    "query":"How do i change a string variable into an int\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1442380000000,
    "intention":"NA",
    "query":"how to use child class toString method\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1442380000000,
    "intention":"NA",
    "query":"how to call a tostring method\n",
    "u_id":"A0011"
  },
   {
    "timestamp":1442380000000,
    "intention":"NA",
    "query":"how to call a tostring method\n",
    "u_id":"A0011"
  },
   {
    "timestamp":1442380000000,
    "intention":"NA",
    "query":"how to call a tostring method\n",
    "u_id":"A0011"
  },
   {
    "timestamp":1442380000000,
    "intention":"NA",
    "query":"how to call a tostring method\n",
    "u_id":"A0011"
  },
   {
    "timestamp":1442380000000,
    "intention":"NA",
    "query":"how to call a tostring method\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1442380000000,
    "intention":"KS",
    "query":"how to format a number as a percentage\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1442380000000,
    "intention":"NA",
    "query":"how to format a number as a percentage in java\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1442600000000,
    "intention":"NA",
    "query":"how to use decimal format\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1443830000000,
    "intention":"KS",
    "query":"gridlayout movement\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1443830000000,
    "intention":"NA",
    "query":"gridlayout move\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1443830000000,
    "intention":"NA",
    "query":"gridlayout move to another cell java\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1443830000000,
    "intention":"NA",
    "query":"can I use GridLayout with borderLayout\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1443840000000,
    "intention":"KS",
    "query":"how do i iterate through a vector\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1443840000000,
    "intention":"NA",
    "query":"how do i iterate through a vector of strings\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1444500000000,
    "intention":"KS",
    "query":"Array of colors\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1444500000000,
    "intention":"NA",
    "query":"java color array\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1444500000000,
    "intention":"NA",
    "query":"arrays\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1444500000000,
    "intention":"KS",
    "query":"JRadioButton Array\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1445300000000,
    "intention":"KS",
    "query":"how to sort alphabetically\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1445300000000,
    "intention":"KS",
    "query":"how to sort alphabetically\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1445300000000,
    "intention":"KS",
    "query":"how to sort alphabetically\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1445300000000,
    "intention":"KS",
    "query":"how to sort alphabetically\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1445300000000,
    "intention":"KS",
    "query":"how to sort alphabetically\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1445300000000,
    "intention":"KS",
    "query":"how to sort alphabetically\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1445300000000,
    "intention":"NA",
    "query":"sort alphabetically java\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1445800000000,
    "intention":"PS",
    "query":"scanner breaking program\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1445800000000,
    "intention":"PS",
    "query":"obsolete methods\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1445810000000,
    "intention":"PS",
    "query":"scanner not scanning file\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1446310000000,
    "intention":"KS",
    "query":"java keyboard scanner\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1446320000000,
    "intention":"KS",
    "query":"can i use logbase in java\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1447990000000,
    "intention":"KS",
    "query":"can you add a char to a string\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1447990000000,
    "intention":"NA",
    "query":"can you add a char to a string java\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1447990000000,
    "intention":"NA",
    "query":"convert char to string java\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1442370000000,
    "intention":"KS",
    "query":"currency format\n",
    "u_id":"A0054"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"scanner\n",
    "u_id":"A0054"
  },
  {
    "timestamp":1444950000000,
    "intention":"ML",
    "query":"scanner\n",
    "u_id":"A0054"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"parseint\n",
    "u_id":"A0054"
  },
  {
    "timestamp":1444950000000,
    "intention":"ML",
    "query":"3 partition merge sort\n",
    "u_id":"A0077"
  },
  {
    "timestamp":1444950000000,
    "intention":"ML",
    "query":"3 way merge sort\n",
    "u_id":"A0077"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"merge sort 3 partition\n",
    "u_id":"A0077"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"merge sort\n",
    "u_id":"A0077"
  },
  {
    "timestamp":1444960000000,
    "intention":"ML",
    "query":"partition merge sort\n",
    "u_id":"A0077"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"3 partition merge sort\n",
    "u_id":"A0075"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"merge sort\n",
    "u_id":"A0075"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"merge sort arraylist\n",
    "u_id":"A0075"
  },
  {
    "timestamp":1440600000000,
    "intention":"PS",
    "query":"while and if loops\n",
    "u_id":"A0048"
  },
  {
    "timestamp":1440600000000,
    "intention":"KS",
    "query":"users enter input into an array\n",
    "u_id":"A0048"
  },
  {
    "timestamp":1440610000000,
    "intention":"KS",
    "query":"how to add all positive integers entered\n",
    "u_id":"A0048"
  },
  {
    "timestamp":1440610000000,
    "intention":"NA",
    "query":"java how to add all positive integers entered\n",
    "u_id":"A0048"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"merge sort\n",
    "u_id":"A0048"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"merge sort\n",
    "u_id":"A0048"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"3=partition merge sort\n",
    "u_id":"A0048"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"3-partition merge sort\n",
    "u_id":"A0048"
  },
  {
    "timestamp":1444260000000,
    "intention":"PS",
    "query":"parse int in an action listener class\n",
    "u_id":"A0030"
  },
  {
    "timestamp":1443290000000,
    "intention":"ML",
    "query":"in.hasNextDouble\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1443290000000,
    "intention":"ML",
    "query":"in.hasNextDouble()\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1443320000000,
    "intention":"KS",
    "query":"makeCenterPanel()\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1443320000000,
    "intention":"ML",
    "query":"makeCenterPanel()\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1443320000000,
    "intention":"NA",
    "query":"makeCenterPanel\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1443320000000,
    "intention":"NA",
    "query":"makeWestPanel\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1443930000000,
    "intention":"KS",
    "query":".equals\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1443930000000,
    "intention":"PS",
    "query":"how to use a vector in Java\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1443930000000,
    "intention":"KS",
    "query":"using vector\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1443930000000,
    "intention":"KS",
    "query":"append textarea in java\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1443930000000,
    "intention":"KS",
    "query":"+=\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1443930000000,
    "intention":"ML",
    "query":"+=\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1443940000000,
    "intention":"ML",
    "query":"how to call toString method\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1444580000000,
    "intention":"ML",
    "query":"in.nextDouble()\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1444580000000,
    "intention":"KS",
    "query":"in.nextDouble()\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1444580000000,
    "intention":"ML",
    "query":"System.out.println() method\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1444600000000,
    "intention":"ML",
    "query":".this\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1444600000000,
    "intention":"NA",
    "query":".this()\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1444600000000,
    "intention":"NA",
    "query":"this.\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1444600000000,
    "intention":"NA",
    "query":"this. method\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1444600000000,
    "intention":"ML",
    "query":"example toString()\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1444600000000,
    "intention":"NA",
    "query":"toString()\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1444670000000,
    "intention":"PS",
    "query":"call toString from abstract method\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1444670000000,
    "intention":"NA",
    "query":"toString abstract class\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"3 partition merge sort\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"2 partition merge sort\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1445190000000,
    "intention":"KS",
    "query":"runtime exception\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1445190000000,
    "intention":"ML",
    "query":"runtime exception\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1447450000000,
    "intention":"KS",
    "query":"bad data exception\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1447450000000,
    "intention":"ML",
    "query":"bad data exception\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1441920000000,
    "intention":"NA",
    "query":"inheritance/super\n",
    "u_id":"A0071"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"arraylist syntax\n",
    "u_id":"A0071"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"arraylist getters\n",
    "u_id":"A0071"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"arraylist getters and setters\n",
    "u_id":"A0071"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"how to get elements from arraylist\n",
    "u_id":"A0071"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"how to access elements in arraylist\n",
    "u_id":"A0071"
  },
  {
    "timestamp":1444960000000,
    "intention":"NA",
    "query":"merge sort\n",
    "u_id":"A0071"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"parse string to int\n",
    "u_id":"A0049"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"parse string to int java\n",
    "u_id":"A0049"
  },
  {
    "timestamp":1444970000000,
    "intention":"PS",
    "query":"java mouselistener\n",
    "u_id":"A0049"
  },
  {
    "timestamp":1444970000000,
    "intention":"KS",
    "query":"java add mouselistener\n",
    "u_id":"A0049"
  },
  {
    "timestamp":1444970000000,
    "intention":"KS",
    "query":"java clear canvas\n",
    "u_id":"A0049"
  },
  {
    "timestamp":1444970000000,
    "intention":"KS",
    "query":"java how to clear canvas\n",
    "u_id":"A0049"
  },
  {
    "timestamp":1444970000000,
    "intention":"KS",
    "query":"java difference between getx and getxonscreen\n",
    "u_id":"A0049"
  },
  {
    "timestamp":1444970000000,
    "intention":"KS",
    "query":"java getxonscreen\n",
    "u_id":"A0049"
  },
  {
    "timestamp":1444970000000,
    "intention":"KS",
    "query":"java arraylist remove\n",
    "u_id":"A0049"
  },
  {
    "timestamp":1444970000000,
    "intention":"KS",
    "query":"java switch\n",
    "u_id":"A0049"
  },
  {
    "timestamp":1444970000000,
    "intention":"PS",
    "query":"java nested class error\n",
    "u_id":"A0049"
  },
  {
    "timestamp":1441300000000,
    "intention":"ML",
    "query":"how to use tostring in java\n",
    "u_id":"A0029"
  },
  {
    "timestamp":1442510000000,
    "intention":"PS",
    "query":"how to parse\n",
    "u_id":"A0029"
  },
  {
    "timestamp":1442510000000,
    "intention":"PS",
    "query":"parseStringToProduct\n",
    "u_id":"A0029"
  },
  {
    "timestamp":1442510000000,
    "intention":"PS",
    "query":"parse string\n",
    "u_id":"A0029"
  },
  {
    "timestamp":1442510000000,
    "intention":"NA",
    "query":"parse string java\n",
    "u_id":"A0029"
  },
  {
    "timestamp":1442520000000,
    "intention":"PS",
    "query":"java typecast string to int\n",
    "u_id":"A0029"
  },
  {
    "timestamp":1442550000000,
    "intention":"ML",
    "query":"variables abstract class java\n",
    "u_id":"A0029"
  },
  {
    "timestamp":1442600000000,
    "intention":"PS",
    "query":"java decimal format\n",
    "u_id":"A0029"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"3 partition merge sort\n",
    "u_id":"A0029"
  },
  {
    "timestamp":1444950000000,
    "intention":"ML",
    "query":"merge sort\n",
    "u_id":"A0029"
  },
  {
    "timestamp":1444960000000,
    "intention":"ML",
    "query":"recursion\n",
    "u_id":"A0029"
  },
  {
    "timestamp":1444960000000,
    "intention":"PS",
    "query":"swap arraylist objects\n",
    "u_id":"A0029"
  },
  {
    "timestamp":1444960000000,
    "intention":"ML",
    "query":"arraylist swap\n",
    "u_id":"A0029"
  },
  {
    "timestamp":1444960000000,
    "intention":"ML",
    "query":"arraylist set\n",
    "u_id":"A0029"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"scanner class\n",
    "u_id":"B0020"
  },
  {
    "timestamp":1441340000000,
    "intention":"ML",
    "query":"set method\n",
    "u_id":"B0020"
  },
  {
    "timestamp":1441340000000,
    "intention":"NA",
    "query":"set method with multiple strings\n",
    "u_id":"B0020"
  },
  {
    "timestamp":1442530000000,
    "intention":"NA",
    "query":"line to parse array\n",
    "u_id":"B0020"
  },
  {
    "timestamp":1442530000000,
    "intention":"NA",
    "query":"line to parse split\n",
    "u_id":"B0020"
  },
  {
    "timestamp":1442530000000,
    "intention":"NA",
    "query":"lineToParse.split\n",
    "u_id":"B0020"
  },
  {
    "timestamp":1443990000000,
    "intention":"NA",
    "query":"run an applet program\n",
    "u_id":"B0020"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"3-partition merge sort\n",
    "u_id":"B0020"
  },
  {
    "timestamp":1444960000000,
    "intention":"NA",
    "query":"colorlistener class\n",
    "u_id":"B0020"
  },
  {
    "timestamp":1440720000000,
    "intention":"PS",
    "query":"loop\n",
    "u_id":"B0009"
  },
  {
    "timestamp":1440560000000,
    "intention":"KS",
    "query":"dynamic array\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1440560000000,
    "intention":"NA",
    "query":"dynamic array java\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1440560000000,
    "intention":"KS",
    "query":"passing arrays as paramaters\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1440560000000,
    "intention":"NA",
    "query":"passing arrays as parameters java\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1441150000000,
    "intention":"KS",
    "query":"UML\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1441320000000,
    "intention":"ML",
    "query":"constructor java\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1441320000000,
    "intention":"KS",
    "query":"constructor java\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1441320000000,
    "intention":"NA",
    "query":"what is a constructor\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1441320000000,
    "intention":"NA",
    "query":"what is a constructor java\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1441380000000,
    "intention":"ML",
    "query":"\n java\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1441380000000,
    "intention":"KS",
    "query":"\n\n java\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1441850000000,
    "intention":"KS",
    "query":"abstract class java\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1442100000000,
    "intention":"KS",
    "query":"implements vs extends java\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1442540000000,
    "intention":"KS",
    "query":"how many components can you add to a frame using the add method\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1442550000000,
    "intention":"KS",
    "query":"linetoparse java\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1442550000000,
    "intention":"NA",
    "query":"lineToParse\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1442550000000,
    "intention":"NA",
    "query":"type cast\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1442550000000,
    "intention":"NA",
    "query":"type cast java\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1442550000000,
    "intention":"ML",
    "query":"java cast string to int\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1442600000000,
    "intention":"KS",
    "query":"format double java\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1442600000000,
    "intention":"KS",
    "query":"String.format java\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1442600000000,
    "intention":"KS",
    "query":".##\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1442600000000,
    "intention":"NA",
    "query":".string.format java\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1444450000000,
    "intention":"KS",
    "query":"java filled rectangle\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1444530000000,
    "intention":"KS",
    "query":"java radio button\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"merge sort java\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"arraylist java\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1444970000000,
    "intention":"KS",
    "query":"gui with radio buttons java\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1444970000000,
    "intention":"PS",
    "query":"applet not initialized java\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1444970000000,
    "intention":"KS",
    "query":"adding panels to japplet java\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1444970000000,
    "intention":"NA",
    "query":"jpanel japplet java\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1444970000000,
    "intention":"KS",
    "query":"container java\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1445970000000,
    "intention":"KS",
    "query":"serialization\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1445980000000,
    "intention":"KS",
    "query":"comparing objects\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1446000000000,
    "intention":"KS",
    "query":"lexicograph java\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1440720000000,
    "intention":"KS",
    "query":"Artifical Intelligence\n",
    "u_id":"B0005"
  },
  {
    "timestamp":1444260000000,
    "intention":"NA",
    "query":"duplicates in a vector\n",
    "u_id":"B0005"
  },
  {
    "timestamp":1444260000000,
    "intention":"NA",
    "query":"duplicates in a vector of objects\n",
    "u_id":"B0005"
  },
  {
    "timestamp":1444260000000,
    "intention":"NA",
    "query":"duplicates in a vector of objects Java\n",
    "u_id":"B0005"
  },
  {
    "timestamp":1441340000000,
    "intention":"ML",
    "query":"proper way to reference one class from another\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "intention":"NA",
    "query":"reference a child class\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "intention":"KS",
    "query":"Do I need to have subclass variables in main class\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "intention":"KS",
    "query":"java car makes inheritance\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "intention":"NA",
    "query":"java inheritance toString\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "intention":"KS",
    "query":"create a reference to another class\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "intention":"NA",
    "query":"create a reference to another class java\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442200000000,
    "intention":"KS",
    "query":"What does the # mean when declaring a variable\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442200000000,
    "intention":"KS",
    "query":"What does the # mean when declaring a variable java\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442200000000,
    "intention":"NA",
    "query":"what does number sign mean in java\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442550000000,
    "intention":"ML",
    "query":"How to get numberformat percentage\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1444620000000,
    "intention":"ML",
    "query":"how to create classes within other classes\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1444620000000,
    "intention":"NA",
    "query":"how to create classes within other classes java\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1440550000000,
    "intention":"KS",
    "query":"for loops\n",
    "u_id":"B0027"
  },
  {
    "timestamp":1441410000000,
    "intention":"KS",
    "query":"accessor method\n",
    "u_id":"B0027"
  },
  {
    "timestamp":1442610000000,
    "intention":"ML",
    "query":"parse string to product\n",
    "u_id":"B0027"
  },
  {
    "timestamp":1446510000000,
    "intention":"KS",
    "query":"reading file to string java\n",
    "u_id":"B0027"
  },
  {
    "timestamp":1440630000000,
    "intention":"ML",
    "query":"input as separate numbers\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1440630000000,
    "intention":"ML",
    "query":"input numbers separated by spaces\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1440630000000,
    "intention":"ML",
    "query":"input numbers separated by spaces in java\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1440640000000,
    "intention":"KS",
    "query":"separate input into multiple variables\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1440640000000,
    "intention":"ML",
    "query":"seperate input variables\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1440800000000,
    "intention":"ML",
    "query":"while printing multiple times\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1440800000000,
    "intention":"PS",
    "query":"while loop duplicate prints\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1440800000000,
    "intention":"PS",
    "query":"print outside of while loop\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1440800000000,
    "intention":"PS",
    "query":"print outside while loop\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1441240000000,
    "intention":"KS",
    "query":"eclipse wont compile\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1441410000000,
    "intention":"KS",
    "query":"printing toString\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1441410000000,
    "intention":"PS",
    "query":"String toString()\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1441410000000,
    "intention":"NA",
    "query":"java String toString()\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1442290000000,
    "intention":"ML",
    "query":"currancy instance\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1442290000000,
    "intention":"NA",
    "query":"currency instance\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1442290000000,
    "intention":"NA",
    "query":"java currency instance\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1442510000000,
    "intention":"ML",
    "query":"java utility class\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1442510000000,
    "intention":"NA",
    "query":"java make utility class\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1442510000000,
    "intention":"ML",
    "query":"java currency\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1442510000000,
    "intention":"KS",
    "query":"currency instance\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1442510000000,
    "intention":"ML",
    "query":"java NumberFormat currency\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1443480000000,
    "intention":"ML",
    "query":"Java getText\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1443720000000,
    "intention":"KS",
    "query":"Java Gui Display input\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1443720000000,
    "intention":"KS",
    "query":"java put panel into pane\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1443720000000,
    "intention":"KS",
    "query":"cannot convert jpanel to vector\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"java merge sort\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1440550000000,
    "intention":"KS",
    "query":"java for loop syntax\n",
    "u_id":"B0012"
  },
  {
    "timestamp":1440800000000,
    "intention":"PS",
    "query":"compute minimum\n",
    "u_id":"B0012"
  },
  {
    "timestamp":1440800000000,
    "intention":"PS",
    "query":"minimum integers java\n",
    "u_id":"B0012"
  },
  {
    "timestamp":1444080000000,
    "intention":"ML",
    "query":"java gridbaglayout\n",
    "u_id":"A0088"
  },
  {
    "timestamp":1444080000000,
    "intention":"ML",
    "query":"java getSelectedValue()\n",
    "u_id":"A0088"
  },
  {
    "timestamp":1445030000000,
    "intention":"ML",
    "query":"radio buttle\n",
    "u_id":"A0088"
  },
  {
    "timestamp":1445030000000,
    "intention":"NA",
    "query":"Jradiobuttle\n",
    "u_id":"A0088"
  },
  {
    "timestamp":1445030000000,
    "intention":"ML",
    "query":"java radiobuttle\n",
    "u_id":"A0088"
  },
  {
    "timestamp":1445030000000,
    "intention":"NA",
    "query":"java jradiobuttle\n",
    "u_id":"A0088"
  },
  {
    "timestamp":1445390000000,
    "intention":"ML",
    "query":"java boxlayout\n",
    "u_id":"A0088"
  },
  {
    "timestamp":1445890000000,
    "intention":"ML",
    "query":"JAVA array.size\n",
    "u_id":"A0088"
  },
  {
    "timestamp":1446770000000,
    "intention":"ML",
    "query":"java linkedlist\n",
    "u_id":"A0088"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"merge sort\n",
    "u_id":"A0069"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"3-part merge sort\n",
    "u_id":"A0069"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"3-partition merge sort\n",
    "u_id":"A0069"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"3-partition merge sort arraylist\n",
    "u_id":"A0069"
  },
  {
    "timestamp":1440880000000,
    "intention":"PS",
    "query":"how to add whitespace in spim\n",
    "u_id":"A0066"
  },
  {
    "timestamp":1440880000000,
    "intention":"KS",
    "query":"spim when are registers cleared\n",
    "u_id":"A0066"
  },
  {
    "timestamp":1440890000000,
    "intention":"KS",
    "query":"mips not adding correctly\n",
    "u_id":"A0066"
  },
  {
    "timestamp":1440910000000,
    "intention":"ML",
    "query":"mips registers address and memory\n",
    "u_id":"A0066"
  },
  {
    "timestamp":1440910000000,
    "intention":"ML",
    "query":"mips registers address and memory\n",
    "u_id":"A0066"
  },
  {
    "timestamp":1440910000000,
    "intention":"ML",
    "query":"mips what does lw do?\n",
    "u_id":"A0066"
  },
  {
    "timestamp":1443400000000,
    "intention":"NA",
    "query":"JTextArea\n",
    "u_id":"A0066"
  },
  {
    "timestamp":1443400000000,
    "intention":"NA",
    "query":"jtextarea getText\n",
    "u_id":"A0066"
  },
  {
    "timestamp":1445130000000,
    "intention":"PS",
    "query":"java insertion sort\n",
    "u_id":"A0066"
  },
  {
    "timestamp":1440740000000,
    "intention":"KS",
    "query":"definition of a method in java\n",
    "u_id":"A0010"
  },
  {
    "timestamp":1441260000000,
    "intention":"KS",
    "query":"how to make a class\n",
    "u_id":"A0010"
  },
  {
    "timestamp":1441260000000,
    "intention":"NA",
    "query":"how to make a class java\n",
    "u_id":"A0010"
  },
  {
    "timestamp":1441270000000,
    "intention":"KS",
    "query":"mutator method java\n",
    "u_id":"A0010"
  },
  {
    "timestamp":1441270000000,
    "intention":"KS",
    "query":"invalid method declaration; return type required\n",
    "u_id":"A0010"
  },
  {
    "timestamp":1441320000000,
    "intention":"PS",
    "query":" error: cannot find symbol this.\n",
    "u_id":"A0010"
  },
  {
    "timestamp":1442470000000,
    "intention":"KS",
    "query":"how to use an abstract method\n",
    "u_id":"A0010"
  },
  {
    "timestamp":1442470000000,
    "intention":"NA",
    "query":"how to use abstract methods\n",
    "u_id":"A0010"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"scanner class\n",
    "u_id":"A0010"
  },
  {
    "timestamp":1440550000000,
    "intention":"KS",
    "query":"java for loop syntax\n",
    "u_id":"A0056"
  },
  {
    "timestamp":1440720000000,
    "intention":"KS",
    "query":"what does static mean in Java\n",
    "u_id":"A0056"
  },
  {
    "timestamp":1440720000000,
    "intention":"KS",
    "query":"Vectors in Java\n",
    "u_id":"A0056"
  },
  {
    "timestamp":1440720000000,
    "intention":"KS",
    "query":"using arrays java\n",
    "u_id":"A0056"
  },
  {
    "timestamp":1440830000000,
    "intention":"KS",
    "query":"arrays java\n",
    "u_id":"A0056"
  },
  {
    "timestamp":1440830000000,
    "intention":"NA",
    "query":"using arrays\n",
    "u_id":"A0056"
  },
  {
    "timestamp":1440830000000,
    "intention":"NA",
    "query":"using arrays java\n",
    "u_id":"A0056"
  },
  {
    "timestamp":1440920000000,
    "intention":"KS",
    "query":"copy constructor java\n",
    "u_id":"A0056"
  },
  {
    "timestamp":1440920000000,
    "intention":"ML",
    "query":"deep copy constructor java\n",
    "u_id":"A0056"
  },
  {
    "timestamp":1441150000000,
    "intention":"KS",
    "query":"static classes\n",
    "u_id":"A0056"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"Merge Sort\n",
    "u_id":"A0056"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"Merge Sort arraylist\n",
    "u_id":"A0056"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"merge sort\n",
    "u_id":"A0059"
  },
  {
    "timestamp":1441570000000,
    "intention":"PS",
    "query":"how do you call a parents method\n",
    "u_id":"A0021"
  },
  {
    "timestamp":1441570000000,
    "intention":"PS",
    "query":"how do I call a parent's method from a subclass\n",
    "u_id":"A0021"
  },
  {
    "timestamp":1441590000000,
    "intention":"KS",
    "query":"can you replace a character in a String with another character\n",
    "u_id":"A0021"
  },
  {
    "timestamp":1441590000000,
    "intention":"ML",
    "query":"formatting numbers\n",
    "u_id":"A0021"
  },
  {
    "timestamp":1441590000000,
    "intention":"NA",
    "query":"formatting numbers in java\n",
    "u_id":"A0021"
  },
  {
    "timestamp":1441600000000,
    "intention":"KS",
    "query":"java casting\n",
    "u_id":"A0021"
  },
  {
    "timestamp":1441600000000,
    "intention":"KS",
    "query":"java what is casting\n",
    "u_id":"A0021"
  },
  {
    "timestamp":1443070000000,
    "intention":"KS",
    "query":"how do you add a scroll pane to a text area\n",
    "u_id":"A0021"
  },
  {
    "timestamp":1443070000000,
    "intention":"NA",
    "query":"how do you use JScrollPane\n",
    "u_id":"A0021"
  },
  {
    "timestamp":1443070000000,
    "intention":"KS",
    "query":"how do you tie the enter key to a keyListener event\n",
    "u_id":"A0021"
  },
  {
    "timestamp":1443070000000,
    "intention":"NA",
    "query":"listen for enter key\n",
    "u_id":"A0021"
  },
  {
    "timestamp":1443230000000,
    "intention":"KS",
    "query":"Checking whether a text field has input\n",
    "u_id":"A0021"
  },
  {
    "timestamp":1443580000000,
    "intention":"KS",
    "query":"2 JButtons\n",
    "u_id":"A0021"
  },
  {
    "timestamp":1443590000000,
    "intention":"KS",
    "query":"Implement 2 Buttons in one ActionListener\n",
    "u_id":"A0021"
  },
  {
    "timestamp":1443590000000,
    "intention":"NA",
    "query":"2 JButtons in one ActionListener\n",
    "u_id":"A0021"
  },
  {
    "timestamp":1441320000000,
    "intention":"KS",
    "query":"Java Abstract class\n",
    "u_id":"A0033"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"Merge Sort\n",
    "u_id":"A0033"
  },
  {
    "timestamp":1444980000000,
    "intention":"ML",
    "query":"MouseEvent\n",
    "u_id":"A0033"
  },
  {
    "timestamp":1444980000000,
    "intention":"ML",
    "query":"ButtonGroup\n",
    "u_id":"A0033"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"merge sort\n",
    "u_id":"A0026"
  },
  {
    "timestamp":1444950000000,
    "intention":"ML",
    "query":"merge\n",
    "u_id":"A0026"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"merge method\n",
    "u_id":"A0026"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"read input\n",
    "u_id":"A0026"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"scanner\n",
    "u_id":"A0026"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"declare scanner\n",
    "u_id":"A0026"
  },
  {
    "timestamp":1444960000000,
    "intention":"NA",
    "query":"sort method\n",
    "u_id":"A0026"
  },
  {
    "timestamp":1440780000000,
    "intention":"KS",
    "query":"instantiate an array in Java\n",
    "u_id":"A0022"
  },
  {
    "timestamp":1441040000000,
    "intention":"KS",
    "query":"What are the 10 Laws of coding?\n",
    "u_id":"A0022"
  },
  {
    "timestamp":1441300000000,
    "intention":"PS",
    "query":"toString methods in Java\n",
    "u_id":"A0022"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"MergeSort\n",
    "u_id":"A0022"
  },
  {
    "timestamp":1444950000000,
    "intention":"PS",
    "query":"MergeSort\n",
    "u_id":"A0022"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"arrays\n",
    "u_id":"A0022"
  },
  {
    "timestamp":1444950000000,
    "intention":"NA",
    "query":"[arrays in Java]\n",
    "u_id":"A0022"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"arrays in Java\n",
    "u_id":"A0022"
  },
  {
    "timestamp":1445020000000,
    "intention":"KS",
    "query":"adding variables to an array in Java\n",
    "u_id":"A0022"
  },
  {
    "timestamp":1445020000000,
    "intention":"KS",
    "query":"ActionEvent, Java\n",
    "u_id":"A0022"
  },
  {
    "timestamp":1442620000000,
    "intention":"ML",
    "query":"parse\n",
    "u_id":"B0013"
  },
  {
    "timestamp":1442620000000,
    "intention":"NA",
    "query":"parse java\n",
    "u_id":"B0013"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"merge sort\n",
    "u_id":"A0087"
  },
  {
    "timestamp":1440720000000,
    "intention":"ML",
    "query":"how to add arraylist\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1441320000000,
    "intention":"ML",
    "query":"how to call a getter method from a different class\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1441320000000,
    "intention":"KS",
    "query":"how to make a myout.txt\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1442430000000,
    "intention":"KS",
    "query":"#\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1442430000000,
    "intention":"NA",
    "query":"# in constructor clas\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1442430000000,
    "intention":"NA",
    "query":"# in constructor class\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1442430000000,
    "intention":"NA",
    "query":"protected class\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1442430000000,
    "intention":"NA",
    "query":"protected class java\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1442430000000,
    "intention":"KS",
    "query":"java protected method\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1442430000000,
    "intention":"KS",
    "query":"split method java\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1443640000000,
    "intention":"PS",
    "query":"button listener\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1443640000000,
    "intention":"NA",
    "query":"button listener java\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1443640000000,
    "intention":"NA",
    "query":"java listener\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1443640000000,
    "intention":"NA",
    "query":"jpanel java\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1443640000000,
    "intention":"NA",
    "query":"JFrame\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1443640000000,
    "intention":"NA",
    "query":"JFrame java\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1443650000000,
    "intention":"NA",
    "query":"decimal format\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1443650000000,
    "intention":"NA",
    "query":"adding to JList\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1440730000000,
    "intention":"KS",
    "query":"do while loop syntax java\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1440730000000,
    "intention":"KS",
    "query":"how do I store user inputs into an array\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1440730000000,
    "intention":"PS",
    "query":"how do I store user inputs into an array java\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1440730000000,
    "intention":"NA",
    "query":"convert user input into an array\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1440730000000,
    "intention":"NA",
    "query":"java convert user input into an array\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1440730000000,
    "intention":"NA",
    "query":"java how to store user input into an array\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1440800000000,
    "intention":"PS",
    "query":"storing user inputs into an array\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1441400000000,
    "intention":"PS",
    "query":"call method of another class within a class method\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1441400000000,
    "intention":"NA",
    "query":"call method of another class\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1441400000000,
    "intention":"NA",
    "query":"call method of another class java\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1441410000000,
    "intention":"PS",
    "query":"what is java.lang.NullPointerException\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444080000000,
    "intention":"PS",
    "query":"boxlayout\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444080000000,
    "intention":"NA",
    "query":"add JLable to JPanel\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444080000000,
    "intention":"NA",
    "query":"box layout can't be shared\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444080000000,
    "intention":"NA",
    "query":"BoxLayout cannot be shared\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444080000000,
    "intention":"NA",
    "query":"BoxLayout  be shared\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444080000000,
    "intention":"NA",
    "query":"Jpanel with box layaout\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444080000000,
    "intention":"NA",
    "query":"Jpanel with box layout\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444100000000,
    "intention":"PS",
    "query":"set spacing in BoxLayout\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444100000000,
    "intention":"PS",
    "query":"concatenate text in JTextArea\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444100000000,
    "intention":"PS",
    "query":"clear text field after button pushed\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444100000000,
    "intention":"NA",
    "query":"clear textfield after button pushed\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444100000000,
    "intention":"NA",
    "query":"clear textfield after event\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444100000000,
    "intention":"NA",
    "query":"clear textfield after event JAva\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444100000000,
    "intention":"NA",
    "query":"clear textfield after event Java\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444100000000,
    "intention":"NA",
    "query":"remove user input from Text area\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444100000000,
    "intention":"PS",
    "query":"get Text from textarea and translate String to integer\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444100000000,
    "intention":"NA",
    "query":"method to convert String to integer\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444100000000,
    "intention":"PS",
    "query":"convert String to int\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444100000000,
    "intention":"PS",
    "query":"clear text area\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444100000000,
    "intention":"NA",
    "query":"clear text area java\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444940000000,
    "intention":"PS",
    "query":"how to create radio buttons\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444940000000,
    "intention":"NA",
    "query":"how to create radio buttons java\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444940000000,
    "intention":"NA",
    "query":"default color to draw rectangles is black\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444940000000,
    "intention":"NA",
    "query":"how to create a radio button java\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"io\n",
    "u_id":"A0015"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"method overloaded\n",
    "u_id":"A0015"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"method overloaded\n",
    "u_id":"A0015"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"method overloaded\n",
    "u_id":"A0015"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"method overloaded\n",
    "u_id":"A0015"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"class inheritance\n",
    "u_id":"A0015"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"class inheritance\n",
    "u_id":"A0015"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"class inheritance\n",
    "u_id":"A0015"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"class inheritance\n",
    "u_id":"A0015"
  },

  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"class inheritance\n",
    "u_id":"A0015"
  },

  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"class inheritance\n",
    "u_id":"A0015"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"class inheritance\n",
    "u_id":"A0015"
  },

  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"class inheritance\n",
    "u_id":"A0015"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"class inheritance\n",
    "u_id":"A0015"
  },
  
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"method overloaded\n",
    "u_id":"A0015"
  },

  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"method overloaded\n",
    "u_id":"A0015"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"method overloaded\n",
    "u_id":"A0015"
  },
  {
    "timestamp":1444950000000,
    "intention":"KS",
    "query":"method overloaded\n",
    "u_id":"A0015"
  },
  {
    "timestamp":1440720000000,
    "intention":"KS",
    "query":"how to java\n",
    "u_id":"A0050"
  },
  {
    "timestamp":1440720000000,
    "intention":"KS",
    "query":"how to get input from the user\n",
    "u_id":"A0050"
  },
  {
    "timestamp":1440720000000,
    "intention":"NA",
    "query":"how to cin in java\n",
    "u_id":"A0050"
  },
  {
    "timestamp":1440720000000,
    "intention":"NA",
    "query":"how to read from standard input\n",
    "u_id":"A0050"
  },
  {
    "timestamp":1440720000000,
    "intention":"NA",
    "query":"how to initialize an array\n",
    "u_id":"A0050"
  },
  {
    "timestamp":1440790000000,
    "intention":"KS",
    "query":"what is this.\n",
    "u_id":"A0050"
  },
  {
    "timestamp":1440790000000,
    "intention":"NA",
    "query":"what is the function of this.\n",
    "u_id":"A0050"
  },
  {
    "timestamp":1440790000000,
    "intention":"NA",
    "query":"do while loop.\n",
    "u_id":"A0050"
  },
  {
    "timestamp":1440790000000,
    "intention":"NA",
    "query":"do while loop.in java\n",
    "u_id":"A0050"
  },
  {
    "timestamp":1440790000000,
    "intention":"NA",
    "query":"java do while loop\n",
    "u_id":"A0050"
  },
  {
    "timestamp":1440810000000,
    "intention":"KS",
    "query":"do while loop\n",
    "u_id":"A0050"
  },
  {
    "timestamp":1440810000000,
    "intention":"KS",
    "query":"do while loop\n",
    "u_id":"A0050"
  },
  {
    "timestamp":1440810000000,
    "intention":"NA",
    "query":"java do while loop\n",
    "u_id":"A0050"
  },
  {
    "timestamp":1440810000000,
    "intention":"KS",
    "query":"arrays\n",
    "u_id":"A0050"
  },
  {
    "timestamp":1440810000000,
    "intention":"NA",
    "query":"how to initialize an array\n",
    "u_id":"A0050"
  },
  {
    "timestamp":1440810000000,
    "intention":"KS",
    "query":"how to declare a new int\n",
    "u_id":"A0050"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"object creation\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"object creation\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1440570000000,
    "intention":"KS",
    "query":"object creation\n",
    "u_id":"A0011"
  },

]