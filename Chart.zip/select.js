var select = [
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10638549/3-way-mergesort",
    "text":"public static void mergesort(int[] data) {     int elements = data.length - 1;\n",
    "u_id":"A0042"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10638549/3-way-mergesort",
    "text":"public static void mergesort(int[] data) {     int elements = data.length - 1;\n",
    "u_id":"A0042"
  },
  {
    "timestamp":1445510000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/20429840/java-add-two-tabs-into-jpanel",
    "text":"import java.awt.BorderLayout; import javax.swing.JButton;\n",
    "u_id":"A0042"
  },
  {
    "timestamp":1445510000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/20429840/java-add-two-tabs-into-jpanel",
    "text":"JTabbedPane(); \n",
    "u_id":"A0042"
  },
  {
    "timestamp":1445510000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/20429840/java-add-two-tabs-into-jpanel",
    "text":"import java.awt.BorderLayout; import javax.swing.JButton;\n",
    "u_id":"A0042"
  },
  {
    "timestamp":1445520000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14999392/count-button-clicks",
    "text":"mport java.awt.BorderLayout; import j\n",
    "u_id":"A0042"
  },
  {
    "timestamp":1445520000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14999392/count-button-clicks",
    "text":"a\n",
    "u_id":"A0042"
  },
  {
    "timestamp":1445520000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14999392/count-button-clicks",
    "text":"import java.awt.BorderLayout; import java.awt.EventQueue;\n",
    "u_id":"A0042"
  },
  {
    "timestamp":1445520000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/8183426/factorial-using-recursion-in-java",
    "text":"class Calculation {\n",
    "u_id":"A0042"
  },
  {
    "timestamp":1445520000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/8183426/factorial-using-recursion-in-java",
    "text":"     }\n",
    "u_id":"A0042"
  },
  {
    "timestamp":1445520000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/8183426/factorial-using-recursion-in-java",
    "text":"     }\n",
    "u_id":"A0042"
  },
  {
    "timestamp":1445520000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/8183426/factorial-using-recursion-in-java",
    "text":"  do not create one more variable\n",
    "u_id":"A0042"
  },
  {
    "timestamp":1445520000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/8183426/factorial-using-recursion-in-java",
    "text":"  do not create one more variable\n",
    "u_id":"A0042"
  },
  {
    "timestamp":1445520000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/8183426/factorial-using-recursion-in-java",
    "text":"import java.util.Scanner; \n",
    "u_id":"A0042"
  },
  {
    "timestamp":1445520000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14999392/count-button-clicks",
    "text":"import java.awt.BorderLayout; import java.awt.EventQueue;\n",
    "u_id":"A0042"
  },
  {
    "timestamp":1443670000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2536873/how-can-i-set-size-of-a-button",
    "text":"setPreferredSize\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1443670000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2536873/how-can-i-set-size-of-a-button",
    "text":"setPreferredSize\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1443670000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2536873/how-can-i-set-size-of-a-button",
    "text":"setPreferredSize\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1443670000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2536873/how-can-i-set-size-of-a-button",
    "text":"        btn.setPreferredSize(new Dimension(40, 40)); \n",
    "u_id":"A0041"
  },
  {
    "timestamp":1443850000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/20099397/how-to-copy-an-item-from-jlist-to-another",
    "text":" Stack Overflow\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1447400000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15958495/linked-lists-remove-element-at-an-index",
    "text":"if (index < 0) {\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1447920000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/26699089/infix-to-postfix-using-stacks-java",
    "text":"s\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1447920000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2742198/java-operator-precedence-comparison",
    "text":"default\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1447920000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5034580/comparing-chars-in-java",
    "text":"to \n",
    "u_id":"A0041"
  },
  {
    "timestamp":1447920000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5034580/comparing-chars-in-java",
    "text":"If you have a character you'll first need to convert it to a string before you can use a regular expression: \n",
    "u_id":"A0041"
  },
  {
    "timestamp":1447920000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5034580/comparing-chars-in-java",
    "text":"If you have a character you'll first need to convert it to a string before you can use a regular expression: \n",
    "u_id":"A0041"
  },
  {
    "timestamp":1447920000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5034580/comparing-chars-in-java",
    "text":"toString\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1447920000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5034580/comparing-chars-in-java",
    "text":"matches\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1447920000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5034580/comparing-chars-in-java",
    "text":"A-Z\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1447920000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5034580/comparing-chars-in-java",
    "text":"A-Z\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1447920000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5034580/comparing-chars-in-java",
    "text":"A-Z\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1447920000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5034580/comparing-chars-in-java",
    "text":"[A-Z?]\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1447920000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5034580/comparing-chars-in-java",
    "text":"[A-Z?]\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1447920000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5034580/comparing-chars-in-java",
    "text":" Do I need to write it like:\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1447920000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/26699089/infix-to-postfix-using-stacks-java",
    "text":"!isOperator\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1447920000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/26699089/infix-to-postfix-using-stacks-java",
    "text":"= \n",
    "u_id":"A0041"
  },
  {
    "timestamp":1447920000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/26699089/infix-to-postfix-using-stacks-java",
    "text":"= \n",
    "u_id":"A0041"
  },
  {
    "timestamp":1447920000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/26699089/infix-to-postfix-using-stacks-java",
    "text":"*\n",
    "u_id":"A0041"
  },
  {
    "timestamp":1443730000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4976838/jlists-number-of-elements-in-the-list",
    "text":"myJList.getModel().getSize();\n",
    "u_id":"A0048"
  },
  {
    "timestamp":1444940000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/16987727/removing-last-object-of-arraylist-in-java",
    "text":"remove(list.size() - 1)\n",
    "u_id":"A0048"
  },
  {
    "timestamp":1446490000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/367626/how-do-i-fix-the-expression-of-type-list-needs-unchecked-conversion",
    "text":"ning-free approach \n",
    "u_id":"A0048"
  },
  {
    "timestamp":1442470000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/698261/how-do-you-format-a-fractional-percentage-with-java-text-messageformat",
    "text":"setMaximumFractionDigits\n",
    "u_id":"A0044"
  },
  {
    "timestamp":1442470000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/698261/how-do-you-format-a-fractional-percentage-with-java-text-messageformat",
    "text":"NumberFormat percentFormat = NumberFormat.getPercentInstance(); percentFormat.setMaximumFractionDigits(1);\n",
    "u_id":"A0044"
  },
  {
    "timestamp":1446540000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5601232/finding-the-minimum-of-an-array-using-recursion",
    "text":"f (index == elements.length - 1) {     return elements[index];\n",
    "u_id":"A0044"
  },
  {
    "timestamp":1444080000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/1046809/string-contains-in-java",
    "text":"contains\n",
    "u_id":"A0029"
  },
  {
    "timestamp":1444850000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4137563/creating-panels-with-radio-buttons-that-change-text-using-arrays",
    "text":"size = new JRadioButton[7];\n",
    "u_id":"A0029"
  },
  {
    "timestamp":1444940000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/27968757/java-swing-button-group-setselected-function",
    "text":" up vote\n",
    "u_id":"A0029"
  },
  {
    "timestamp":1441520000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/ask",
    "text":"li $t1, some_number\n",
    "u_id":"A0066"
  },
  {
    "timestamp":1441520000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/ask",
    "text":"li $t1, some_number\n",
    "u_id":"A0066"
  },
  {
    "timestamp":1441520000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/ask",
    "text":"li $t1, some_number\n",
    "u_id":"A0066"
  },
  {
    "timestamp":1442100000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12207574/programmatically-change-the-desktop-wallpaper-periodically",
    "text":"import java.util.*; \n",
    "u_id":"A0066"
  },
  {
    "timestamp":1442560000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/ask",
    "text":"enter code here\n",
    "u_id":"A0066"
  },
  {
    "timestamp":1442560000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/ask",
    "text":"enter code here\n",
    "u_id":"A0066"
  },
  {
    "timestamp":1442560000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/ask",
    "text":"enter code here\n",
    "u_id":"A0066"
  },
  {
    "timestamp":1442560000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/ask",
    "text":"enter code here\n",
    "u_id":"A0066"
  },
  {
    "timestamp":1442560000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/ask",
    "text":"enter code here\n",
    "u_id":"A0066"
  },
  {
    "timestamp":1442560000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/ask",
    "text":"i\n",
    "u_id":"A0066"
  },
  {
    "timestamp":1442560000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/ask",
    "text":"i\n",
    "u_id":"A0066"
  },
  {
    "timestamp":1442560000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/ask",
    "text":"enter code here\n",
    "u_id":"A0066"
  },
  {
    "timestamp":1442560000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/32646007/how-to-return-an-abstract-type",
    "text":"I tried this and it works, however \n",
    "u_id":"A0066"
  },
  {
    "timestamp":1442560000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/32646007/how-to-return-an-abstract-type",
    "text":"I tried this and it works, however \n",
    "u_id":"A0066"
  },
  {
    "timestamp":1442560000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/32646007/how-to-return-an-abstract-type",
    "text":"I tried this and it works, however \n",
    "u_id":"A0066"
  },
  {
    "timestamp":1442600000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9189926/java-percentage-to-show-decimals",
    "text":"numberFormat.setMinimumFractionDigits(3);\n",
    "u_id":"A0066"
  },
  {
    "timestamp":1443400000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=jtextarea+getText",
    "text":" 1 2\n",
    "u_id":"A0066"
  },
  {
    "timestamp":1444890000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/ask",
    "text":"enter code here\n",
    "u_id":"A0066"
  },
  {
    "timestamp":1444890000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/ask",
    "text":"enter code here\n",
    "u_id":"A0066"
  },
  {
    "timestamp":1444890000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/ask",
    "text":"enter code here\n",
    "u_id":"A0066"
  },
  {
    "timestamp":1444890000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/ask",
    "text":"enter code here\n",
    "u_id":"A0066"
  },
  {
    "timestamp":1445310000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/11496700/how-to-use-printwriter-and-file-classes-in-java",
    "text":" in Java? \n",
    "u_id":"A0066"
  },
  {
    "timestamp":1444960000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10768619/paint-and-repaint-in-java",
    "text":" This method holds instructions to paint this component. Actually, in Swing, you should change paintComponent() instead of paint(), as paint calls paintBorder(), paintComponent() and paintChildren(). You shouldn't call this method directly, you should call repaint() instead.\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1444980000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/3515496/java-remove-last-known-item-from-arraylist",
    "text":"remove(clients.size() - 1);\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1447270000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12678781/reversing-an-array-in-java",
    "text":"for (i = 0; i < array.length / 2; i++) {   int temp = array[i];\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1447270000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12678781/reversing-an-array-in-java",
    "text":"for (i = 0; i < array.length / 2; i++) {   int temp = array[i];\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1447270000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12678781/reversing-an-array-in-java",
    "text":"for (i = 0; i < array.length / 2; i++) {   int temp = array[i];\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1447280000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9459557/java-remove-duplicates-from-linked-list",
    "text":" \n",
    "u_id":"A0043"
  },
  {
    "timestamp":1447280000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9459557/java-remove-duplicates-from-linked-list",
    "text":" \n",
    "u_id":"A0043"
  },
  {
    "timestamp":1447280000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9459557/java-remove-duplicates-from-linked-list",
    "text":"  \n",
    "u_id":"A0043"
  },
  {
    "timestamp":1447280000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15242702/remove-all-occurrences-of-item-from-a-linked-list",
    "text":"current.getNextNode but you delete using the element index. You should look in the rest of your implementation how this index is managed. Does the first element have index 0 or 1 (you start your loop with 1). What happens to the indexes of all elements when you remove one. Do the elements know their index ? \n",
    "u_id":"A0043"
  },
  {
    "timestamp":1447280000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15242702/remove-all-occurrences-of-item-from-a-linked-list",
    "text":"current.getNextNode but you delete using the element index. You should look in the rest of your implementation how this index is managed. Does the first element have index 0 or 1 (you start your loop with 1). What happens to the indexes of all elements when you remove one. Do the elements know their index ? \n",
    "u_id":"A0043"
  },
  {
    "timestamp":1447280000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15594921/java-custom-singly-linked-list-delete-all-occurrences-of-elements-with-a-par",
    "text":" int deleted_nodes_cnt = 0;   ...\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1447280000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15594921/java-custom-singly-linked-list-delete-all-occurrences-of-elements-with-a-par",
    "text":" int deleted_nodes_cnt = 0;   ...\n",
    "u_id":"A0043"
  },
  {
    "timestamp":1440730000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=java+convert+user+input+into+an+array",
    "text":"va convert user input into an array\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1441400000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=call%20method%20of%20another%20class%20within%20a%20class%20method&s=90278a54-ec03-4db9-a56c-a9ec4c99c390",
    "text":" within a class method\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444080000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=BoxLayout+cannot+be+shared",
    "text":"cannot\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444100000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=clear+textfield+after+button+pushed",
    "text":"button pushed\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444100000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=clear+textfield+after+event+JAva",
    "text":"Ava\n",
    "u_id":"A0039"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=how+to+get+elements+from+arraylist",
    "text":"arraylist\n",
    "u_id":"A0071"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=how+to+get+elements+from+arraylist",
    "text":"how to get elements from arraylist\n",
    "u_id":"A0071"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=how+to+get+elements+from+arraylist",
    "text":"how to get elements from arraylist\n",
    "u_id":"A0071"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2542451/can-i-pass-a-child-class-to-a-reference-of-a-parent-class",
    "text":"lass SubB which is a child class of B: \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2542451/can-i-pass-a-child-class-to-a-reference-of-a-parent-class",
    "text":"lass SubB which is a child class of B: \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2542451/can-i-pass-a-child-class-to-a-reference-of-a-parent-class",
    "text":"y code, I create a SubB and pass it to A: \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2542451/can-i-pass-a-child-class-to-a-reference-of-a-parent-class",
    "text":"y code, I create a SubB and pass it to A: \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/24645741/im-trying-to-access-a-private-variable-from-a-sub-class",
    "text":"ate int shares; private int pricePerShare;\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/24645741/im-trying-to-access-a-private-variable-from-a-sub-class",
    "text":"shares;\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/24645741/im-trying-to-access-a-private-variable-from-a-sub-class",
    "text":"ou can add accessor and mutator methods (or getters\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/24645741/im-trying-to-access-a-private-variable-from-a-sub-class",
    "text":"dd accessor and mutator methods (or gette\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/24645741/im-trying-to-access-a-private-variable-from-a-sub-class",
    "text":"hares; private int pricePerS\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/24645741/im-trying-to-access-a-private-variable-from-a-sub-class",
    "text":"ord record = Q.front(); // <-- I assume your Q contains Record(s).  if (record.getShares() >= sel\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=java%20car%20makes%20inheritance&s=91e11bff-c975-4495-aca0-ae9600210da4",
    "text":"car makes inheritance\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/31559666/inheritance-getter-and-tostring-java",
    "text":"uck on getter method in subclass. Here is the Point clas\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/31559666/inheritance-getter-and-tostring-java",
    "text":"uck on getter method in subclass. Here is the Point clas\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/31559666/inheritance-getter-and-tostring-java",
    "text":"re LineSub class:\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/31559666/inheritance-getter-and-tostring-java",
    "text":"re LineSub class:\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/31559666/inheritance-getter-and-tostring-java",
    "text":" up vote\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/31559666/inheritance-getter-and-tostring-java",
    "text":" up vote\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/31559666/inheritance-getter-and-tostring-java",
    "text":" up vote\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/29353240/how-do-i-print-using-tostring-using-inheritance-in-java",
    "text":" out while using the return super.toString(), but Iget errors saying cannot find symbol for stus, but I have it right before starting the s\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/29353240/how-do-i-print-using-tostring-using-inheritance-in-java",
    "text":" public class StuTest2\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/29353240/how-do-i-print-using-tostring-using-inheritance-in-java",
    "text":" public class StuTest2\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2871952/how-do-i-get-is-it-possible-to-a-reference-to-the-class-that-creates-an-instan",
    "text":" up vote\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2871952/how-do-i-get-is-it-possible-to-a-reference-to-the-class-that-creates-an-instan",
    "text":" create a new instance of a class that needs a member of the calling class. But i can't pass a reference to the calling class through the constructor. \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2871952/how-do-i-get-is-it-possible-to-a-reference-to-the-class-that-creates-an-instan",
    "text":" create a new instance of a class that needs a member of the calling class. But i can't pass a reference to the calling class through the constructor. \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2871952/how-do-i-get-is-it-possible-to-a-reference-to-the-class-that-creates-an-instan",
    "text":"emberFromCallingClass()\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2871952/how-do-i-get-is-it-possible-to-a-reference-to-the-class-that-creates-an-instan",
    "text":".WriteLine(trace.GetFrame(1).GetMethod()\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2871952/how-do-i-get-is-it-possible-to-a-reference-to-the-class-that-creates-an-instan",
    "text":"GetMethods or 'GetMember' or similar on the reflected type to get out the actual method you want. \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/20044199/create-object-using-abstract-classes",
    "text":"d better oop ,but I don't understand how to use abstract classes. I have a car class, and a car can be mercedes , audi and volvo. Mercedes cars can have 5 passengers ,can open door and block windows; audi car can have 6 passengers, and just can open door. Volvo car can only have 3 passengers. So, in order to do this, I created an interface:\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/20044199/create-object-using-abstract-classes",
    "text":"d better oop ,but I don't understand how to use abstract classes. I have a car class, and a car can be mercedes , audi and volvo. Mercedes cars can have 5 passengers ,can open door and block windows; audi car can have 6 passengers, and just can open door. Volvo car can only have 3 passengers. So, in order to do this, I created an interface:\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/20044199/create-object-using-abstract-classes",
    "text":"nterface Car{ void openDoor();\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/20044199/create-object-using-abstract-classes",
    "text":"nterface Car{ void openDoor();\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/20044199/create-object-using-abstract-classes",
    "text":"ublic interface Car{ void openDoor();\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"In order to run your program, you have to have a main method.\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"he two parts to the trouble you're having: \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"he two parts to the trouble you're having: \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"You have to understand what static and non-static mean.\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"You have to understand what static and non-static mean.\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"st, as mentioned by others, you can't just have a method run because it's declared and defined in your class. You actually need to have it called, directly or indirectly, by the main method. The main method is written like this:\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"ou have to understand what static and non-static mean. First, as mentioned by others, you can't just have a method run because it's declared and defined in your class. You actually need to have it called, directly or indirectly, by the main method. The main method is written like this:\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"ou have to understand what static and non-static mean. First, as mentioned by others, you can't just have a method run because it's declared and defined in your class. You actually need to have it called, directly or indirectly, by the main method. The main method is written like this:\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":" up vote\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":" up vote\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"n order to run your program, you have to have a main method. You have to understand what static and non-static mean.\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"to the trouble you're having: \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"to the trouble you're having: \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"public static void main(String[] args) {\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"public static void main(String[] args) {\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"ic static void main(String[] args) {     // Do Stuff\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"tand the difference between classes and obj\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"tand the difference between classes and obj\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"ints. They d\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"public class StuffDoer {     public void doStuff {\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"public class StuffDoer {     public void doStuff {\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"public class StuffDoer {     public void doStuff {\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":" Instead, you can first create a new instance object of your class inside of the main method, and then call the non-static instance method off of your instance object:\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":" Instead, you can first create a new instance object of your class inside of the main method, and then call the non-static instance method off of your instance object:\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"d, you can first create a new instance object of your class inside of the main method, and then call the non-static instance method off of your instance object: \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"d, you can first create a new instance object of your class inside of the main method, and then call the non-static instance method off of your instance object: \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"lic class StuffDoer {     public void doStuff {\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"Instead, you can first create a new instance object of your class inside of the main method, and then call the non-static instance method off of your instance object:\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"  Here's the two parts to the trouble you're having:\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"  Here's the two parts to the trouble you're having:\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"Instead, you can first create a new instance object of your class inside of the main method, and then call the non-static instance method off of your instance object:\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":" }\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":" }\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"mething like this won't work: \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"mething like this won't work: \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"ethod, you will notice, is static. It belongs to the class it's declared in, rather than to any instance objects. This means, outside of itself, the main method knows only about the class that it's in, and any other static methods or objects in that class. Things that are not static belong to the actual objects created from the class -- and the main method will know nothing about these actual objects, unless they are created inside of the main method itself. \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"ethod, you will notice, is static. It belongs to the class it's declared in, rather than to any instance objects. This means, outside of itself, the main method knows only about the class that it's in, and any other static methods or objects in that class. Things that are not static belong to the actual objects created from the class -- and the main method will know nothing about these actual objects, unless they are created inside of the main method itself. \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"ice, is static. It belongs to the class it's declared in, rather than to any instance objects. This means, outside of itself, the main method knows only about the class that it's in, and any other static methods or objects in that class. Things that are not static belong to the actual objects created from the class -- and the main method will know nothing about these actual objects, unless they are created inside of the main method itself. \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"ice, is static. It belongs to the class it's declared in, rather than to any instance objects. This means, outside of itself, the main method knows only about the class that it's in, and any other static methods or objects in that class. Things that are not static belong to the actual objects created from the class -- and the main method will know nothing about these actual objects, unless they are created inside of the main method itself. \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/20044199/create-object-using-abstract-classes",
    "text":"dows; audi car can have 6 passengers, and just can open door. Volvo car can only have 3 passengers. So, in order to do this, I created an interface: \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/20044199/create-object-using-abstract-classes",
    "text":"dows; audi car can have 6 passengers, and just can open door. Volvo car can only have 3 passengers. So, in order to do this, I created an interface: \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19980913/java-print-method-wont-work-in-class",
    "text":"ic static void main(String[] args) {         doStuff();  // Won't work!\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441390000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/188547/eclipse-reading-stdin-system-in-from-a-file",
    "text":" Also check this other question for an answer involving launching a J\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1441390000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/188547/eclipse-reading-stdin-system-in-from-a-file",
    "text":"System.setIn(new FileInputStream(filename));\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442550000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23530173/could-not-find-or-load-main-class-error-while-running-java-program-using-cmd-p",
    "text":"org.tij.exercises;\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442550000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9189926/java-percentage-to-show-decimals",
    "text":"o that using NumberFormat in Java. Below is the sample code: \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442590000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9189926/java-percentage-to-show-decimals",
    "text":"an do that using NumberFormat in Java. Below is the sample code: \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442590000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9189926/java-percentage-to-show-decimals",
    "text":"an do that using NumberFormat in Java. Below is the sample code: \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442590000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9189926/java-percentage-to-show-decimals",
    "text":"tNumberInstance(); numberFormat.se\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442590000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9189926/java-percentage-to-show-decimals",
    "text":"s multiplied by 100 for yo\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442590000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/698261/how-do-you-format-a-fractional-percentage-with-java-text-messageformat",
    "text":" the javadoc of java.text.DecimalFormat. \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442590000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/698261/how-do-you-format-a-fractional-percentage-with-java-text-messageformat",
    "text":" the javadoc of java.text.DecimalFormat. \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442590000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4738853/java-decimal-format-parse-to-return-double-value-with-specified-number-of-deci",
    "text":"matterUK.format(valCEWithUKFormat.doubleValue() ); This will give you the output of 1,235\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442590000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9189926/java-percentage-to-show-decimals",
    "text":"ent.format(InterestRate));\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442590000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9189926/java-percentage-to-show-decimals",
    "text":".getNumberInstance(someL\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/47605/string-concatenation-concat-vs-operator",
    "text":" in semantics. If a is null, then a.concat(b) NPEs but a+=b will treat the original value of a as if it were null. Furthermore\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/47605/string-concatenation-concat-vs-operator",
    "text":"with javap -c (included in the Sun JDK). You should see a list\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/47605/string-concatenation-concat-vs-operator",
    "text":"with javap -c (included in the Sun JDK). You should see a list\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/47605/string-concatenation-concat-vs-operator",
    "text":"s if it were null. Furthermore, the concat() method only accepts String values while the + operator will silently convert the argument to a Strin\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/47605/string-concatenation-concat-vs-operator",
    "text":"s if it were null. Furthermore, the concat() method only accepts String values while the + operator will silently convert the argument to a Strin\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/47605/string-concatenation-concat-vs-operator",
    "text":" down vote\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/47605/string-concatenation-concat-vs-operator",
    "text":" down vote\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/47605/string-concatenation-concat-vs-operator",
    "text":" convert the argument to a String (using the toString() method for objects). So the concat() method is more strict in what it accepts. \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/47605/string-concatenation-concat-vs-operator",
    "text":" convert the argument to a String (using the toString() method for objects). So the concat() method is more strict in what it accepts. \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/47605/string-concatenation-concat-vs-operator",
    "text":" accepted\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/47605/string-concatenation-concat-vs-operator",
    "text":" accepted\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/47605/string-concatenation-concat-vs-operator",
    "text":"o the concat() method is more strict in what it accepts. \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/47605/string-concatenation-concat-vs-operator",
    "text":"o the concat() method is more strict in what it accepts. \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/47605/string-concatenation-concat-vs-operator",
    "text":"  No, not quite.\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/7817951/string-concatenation-in-java-when-to-use-stringbuilder-and-concat",
    "text":"n should we use + for concatenation of strings, when is StringBuilder preferred and When is it suitable to use concat. \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/7817951/string-concatenation-in-java-when-to-use-stringbuilder-and-concat",
    "text":"n should we use + for concatenation of strings, when is StringBuilder preferred and When is it suitable to use concat. \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/47605/string-concatenation-concat-vs-operator",
    "text":"append(a)     .append(b)\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/47605/string-concatenation-concat-vs-operator",
    "text":"se {         char ac[] = new char[count + i];\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/47605/string-concatenation-concat-vs-operator",
    "text":"String concatenation: concat() vs + operator \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/47605/string-concatenation-concat-vs-operator",
    "text":"String concatenation: concat() vs + operator \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/26446193/converting-a-do-while-loop-into-a-while-loop",
    "text":"int length = word.length(); if (length > 1)\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/26446193/converting-a-do-while-loop-into-a-while-loop",
    "text":" length = word.length(); if (length > 1)\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/26446193/converting-a-do-while-loop-into-a-while-loop",
    "text":" length = word.length(); if (length > 1)\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/26446193/converting-a-do-while-loop-into-a-while-loop",
    "text":"         word[length - 1] = ch;\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/26446193/converting-a-do-while-loop-into-a-while-loop",
    "text":"nt length = word.length(); if (length > 1)\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/26446193/converting-a-do-while-loop-into-a-while-loop",
    "text":"         ch = word[i];\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/26446193/converting-a-do-while-loop-into-a-while-loop",
    "text":"ord[i] = word[length - 1];         word[length - 1] = ch;\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/26446193/converting-a-do-while-loop-into-a-while-loop",
    "text":"ord[i] = word[length - 1];         word[length - 1] = ch;\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/26446193/converting-a-do-while-loop-into-a-while-loop",
    "text":"         ch = word[i];\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/26446193/converting-a-do-while-loop-into-a-while-loop",
    "text":"         ch = word[i];\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/513832/how-do-i-compare-strings-in-java",
    "text":"nt to test whether two strings have the same value you sh\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/513832/how-do-i-compare-strings-in-java",
    "text":"ntly, if you want to test whether two strings have the same value you should use .equals().\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/513832/how-do-i-compare-strings-in-java",
    "text":"ntly, if you want to test whether two strings have the same value you should use .equals().\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15764228/compare-two-numeric-string-values",
    "text":"eturns an int type. And then c\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15764228/compare-two-numeric-string-values",
    "text":"eturns an int type. And then c\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442900000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15764228/compare-two-numeric-string-values",
    "text":"And then comparison is sam\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1444010000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10093122/how-to-centre-the-buttons-in-my-jframe",
    "text":".add(buttons[i]);\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1444290000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15443704/how-can-i-check-a-negative-solution-of-a-twos-complement-subtraction-equation",
    "text":"e the answer that's in binary, I can't seem to equate it out to the decimal answer before applying twos complement and adding the numbers. \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1444290000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15443704/how-can-i-check-a-negative-solution-of-a-twos-complement-subtraction-equation",
    "text":"e the answer that's in binary, I can't seem to equate it out to the decimal answer before applying twos complement and adding the numbers. \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1444620000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/8176457/importing-other-classes-into-this-class",
    "text":"wClient.java file now? Also, what package declaration are you using in MyWebViewClient.java? \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1444860000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15073477/java-swing-radiobuttons",
    "text":"thing seems correct but ... it does not w\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1444860000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15073477/java-swing-radiobuttons",
    "text":"Add in your constructor also initialization of ChoiceListener\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1444860000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15073477/java-swing-radiobuttons",
    "text":"listener\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1444990000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/25350328/setting-listener-to-jcolorchooser",
    "text":" accepted\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1444990000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/25350328/setting-listener-to-jcolorchooser",
    "text":" accepted\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1444990000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23704024/painting-app-with-color-chooser",
    "text":"(black, Color.BLACK);     colors.put(magenta, Color.MAGENTA);\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1444990000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23704024/painting-app-with-color-chooser",
    "text":"colors.put(red, Color.RED);     colors.put(black, Color.BLACK);\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1444990000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23704024/painting-app-with-color-chooser",
    "text":"colors.put(red, Color.RED);     colors.put(black, Color.BLACK);\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1444990000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23704024/painting-app-with-color-chooser",
    "text":"     colors.put(red, Color.RED);\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1444990000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23704024/painting-app-with-color-chooser",
    "text":"     colors.put(red, Color.RED);\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1444990000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23704024/painting-app-with-color-chooser",
    "text":"pRadioButtons.add(magenta);     jpRadioButtons.add(blue);\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1444990000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23704024/painting-app-with-color-chooser",
    "text":"pRadioButtons.add(magenta);     jpRadioButtons.add(blue);\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1444990000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23704024/painting-app-with-color-chooser",
    "text":"     jpRadioButto\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1444990000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23704024/painting-app-with-color-chooser",
    "text":"ons.setLayout(new GridLayout(3, 1)); \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1446090000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/369512/how-to-compare-objects-by-multiple-fields",
    "text":"     private String firstName;\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1446090000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/13978754/exception-handling-with-wrong-user-input-java",
    "text":"nputMismatchException ime\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1446090000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/13978754/exception-handling-with-wrong-user-input-java",
    "text":"bject selection = scanner.nextInt(), and then cast to an int, you can merely have int selection = scanner.nextInt() and surround that in a try catch that chatches java.util.InputMismatchException, which is the ex\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1446090000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4404084/find-if-a-value-exists-in-arraylist",
    "text":"activeoldestvotes up vote\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1446090000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4073039/calling-one-variable-of-a-class-in-another-class",
    "text":" I am new to the java programming. I have a instance variable in a class which I should call to another class.It should not be static as per the requirements.The code given \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1446840000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/3920602/get-specific-arraylist-item",
    "text":"mainList[3]? \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1446840000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/3920602/get-specific-arraylist-item",
    "text":"et(3)\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1446840000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/3920602/get-specific-arraylist-item",
    "text":"et(3)\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1447450000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5236486/adding-items-to-end-of-linked-list",
    "text":"ject data;     Node next;\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1447450000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5236486/adding-items-to-end-of-linked-list",
    "text":"ject data;     Node next;\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1447450000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4670631/how-to-implement-a-linked-list-in-java",
    "text":" up vote\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1447450000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4670631/how-to-implement-a-linked-list-in-java",
    "text":"trying to implement a simple HashTable in Java that uses a Linked List for collision resolution, which is pretty easy to do in C, but I don't know how to do it in Java, as you can't use pointers... \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1447450000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4670631/how-to-implement-a-linked-list-in-java",
    "text":"trying to implement a simple HashTable in Java that uses a Linked List for collision resolution, which is pretty easy to do in C, but I don't know how to do it in Java, as you can't use pointers... \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1447450000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/354875/reversing-a-linked-list-in-java-recursively",
    "text":"and answering tiny questions (this is the approach in The Little Lisper): \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1447450000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/354875/reversing-a-linked-list-in-java-recursively",
    "text":"istNode Reverse(ListNode list)\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1447450000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/354875/reversing-a-linked-list-in-java-recursively",
    "text":"f (list == null) return null; // first question \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1447450000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/354875/reversing-a-linked-list-in-java-recursively",
    "text":"f (list == null) return null; // first question \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1447450000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/354875/reversing-a-linked-list-in-java-recursively",
    "text":"f (list == null) return null; // first question \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1447450000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/354875/reversing-a-linked-list-in-java-recursively",
    "text":"f (list == null) return null; // first question \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1447450000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/354875/reversing-a-linked-list-in-java-recursively",
    "text":"f (list == null) return null; // first question \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1447450000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/354875/reversing-a-linked-list-in-java-recursively",
    "text":"e reverseRest = Reverse(sec\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1447450000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/354875/reversing-a-linked-list-in-java-recursively",
    "text":"e reverseRest = Reverse(sec\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1447460000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15799034/insertion-sort-vs-selection-sort",
    "text":"ith the smallest element on the right hand side of the current element. \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1447630000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15799034/insertion-sort-vs-selection-sort",
    "text":"current element and exchange it w\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1447640000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/680541/quick-sort-vs-merge-sort",
    "text":"efficiently implemented on most architectures, and in most real-world data, it is possible to make design choices which minimize the probability of requiring quadratic time.\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1447640000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15452255/recursion-removing-duplicates",
    "text":"ic static void removeDuplicates(ArrayList<Integer> list, int counter){ \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1447640000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15452255/recursion-removing-duplicates",
    "text":"         if(list == null){\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1447640000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15452255/recursion-removing-duplicates",
    "text":"         if(list == null){\n",
    "u_id":"A0084"
  },
  {
    "timestamp":1447640000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15452255/recursion-removing-duplicates",
    "text":"emoveDuplicates(ArrayList<Integer> list, int counter){ \n",
    "u_id":"A0084"
  },
  {
    "timestamp":1442370000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=how+to+take+off+certain+decimal+places+in+java",
    "text":"how to take off certain decimal places in java\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1444760000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/3342651/how-can-i-delay-a-java-program-for-a-few-seconds",
    "text":"try {     Thread.sleep(1000);                 //1000 milliseconds is one second.\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1446510000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=write%20a%20text%20(string)%20to%20the%20specified%20file",
    "text":"text (string) to the specified file\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1446620000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9457120/recursive-algorithm-to-find-smallest-element-in-array",
    "text":"if (start== end-1)         return A[0];\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1446700000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=how+to+count+something+in+a+recursive+method+java",
    "text":"how to count something in a recursive method java\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1446700000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=counting+even+values+in+an+array+recursively",
    "text":"counting even values in an array recursively\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1447200000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=counting+the+size+of+nodes+in+a+linked+list+java",
    "text":" java\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1447200000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=counting+the+size+of+nodes+in+a+linked+list+java",
    "text":"size of\n",
    "u_id":"A0020"
  },
  {
    "timestamp":1444840000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=adding%20object%20to%20array",
    "text":" object to\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=ordered+number+array+java",
    "text":"ordered number array java\n",
    "u_id":"A0067"
  },
  {
    "timestamp":1442430000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14956265/java-split-method",
    "text":"str1Arr\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1442430000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14956265/java-split-method",
    "text":"1 2 3\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1442430000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14956265/java-split-method",
    "text":"1 2 3\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1442430000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14956265/java-split-method",
    "text":"tring str2\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1442430000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14956265/java-split-method",
    "text":"str1Array\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1442440000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5585779/converting-string-to-int-in-java",
    "text":" Integer\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1443810000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4262669/refresh-jlist-in-a-jframe",
    "text":"List list = new JList(model\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1443810000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4262669/refresh-jlist-in-a-jframe",
    "text":"JList list = new JList(model);\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1443810000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4262669/refresh-jlist-in-a-jframe",
    "text":"JList list = new JList(model);\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1446060000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/11496700/how-to-use-printwriter-and-file-classes-in-java",
    "text":"Desktop/directory/file.txt\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1446060000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/11496700/how-to-use-printwriter-and-file-classes-in-java",
    "text":"file.txt\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1446060000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/11496700/how-to-use-printwriter-and-file-classes-in-java",
    "text":"file.txt\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1446060000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/11496700/how-to-use-printwriter-and-file-classes-in-java",
    "text":".io.File\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1446060000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/11496700/how-to-use-printwriter-and-file-classes-in-java",
    "text":"file.txt\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1446160000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/24666805/java-only-read-first-line-of-a-file",
    "text":"BufferedReader brTest = new BufferedReader(new FileReader(myTextFile));     text = brTest .readLine();\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1446490000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5601232/finding-the-minimum-of-an-array-using-recursion",
    "text":"ouble val = min(elements, index + 1);\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1447350000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15963549/arraylist-swap-elements",
    "text":"String a = words.get(0); words.set(0, words.get(words.size() - 1));\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1447350000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15963549/arraylist-swap-elements",
    "text":"for (int i = 0; i < list.size(); i++) {         if (i < list.size() - 1) {\n",
    "u_id":"A0025"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=merge",
    "text":"merge\n",
    "u_id":"A0026"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5690121/java-read-input",
    "text":"int  num = scan.nextInt();\n",
    "u_id":"A0026"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5690121/java-read-input",
    "text":"for(int i=0; i < num;i++) {\n",
    "u_id":"A0026"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5690121/java-read-input",
    "text":"int num = Integer.valueOf(scanner.nextLine());\n",
    "u_id":"A0026"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5690121/java-read-input",
    "text":"scan.nextInt();\n",
    "u_id":"A0026"
  },
  {
    "timestamp":1446600000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12617021/measure-size-length-of-singly-linked-list-in-java",
    "text":"int size = 0;    for(Node n = head; n.next != null; n = n.next)\n",
    "u_id":"A0026"
  },
  {
    "timestamp":1446600000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12617021/measure-size-length-of-singly-linked-list-in-java",
    "text":"to pass the list to your method and check currNode!= null : \n",
    "u_id":"A0026"
  },
  {
    "timestamp":1446040000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/1005073/initialization-of-an-arraylist-in-one-line",
    "text":"ArrayList<String> places = new ArrayList<String>();\n",
    "u_id":"A0073"
  },
  {
    "timestamp":1446490000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/8240701/serialize-object-with-outputstream",
    "text":"ObjectOutputStream oos = new ObjectOutputStream(buffer);\n",
    "u_id":"A0073"
  },
  {
    "timestamp":1442020000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=parse&s=38cfc314-672b-421e-933d-533ae3836a2f",
    "text":"parse\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1442020000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=java+parse+string",
    "text":"parse \n",
    "u_id":"A0011"
  },
  {
    "timestamp":1442020000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=java+parse+string",
    "text":"java parse string\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1443830000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=gridlayout+move",
    "text":"move\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1443830000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=gridlayout+move",
    "text":"move\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1445300000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=how%20to%20sort%20alphabetically",
    "text":"how to \n",
    "u_id":"A0011"
  },
  {
    "timestamp":1447990000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=can%20you%20add%20a%20char%20to%20a%20string",
    "text":"can you add a char to a string\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1447990000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=can%20you%20add%20a%20char%20to%20a%20string",
    "text":"can you add a char to a string\n",
    "u_id":"A0011"
  },
  {
    "timestamp":1445630000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/6920025/how-do-i-close-a-java-application-from-the-code",
    "text":"programmers\n",
    "u_id":"A0014"
  },
  {
    "timestamp":1445630000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/6920025/how-do-i-close-a-java-application-from-the-code",
    "text":"programmers\n",
    "u_id":"A0014"
  },
  {
    "timestamp":1446860000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/13023716/need-to-take-input-to-array-until-user-enters-0-java",
    "text":" up vote\n",
    "u_id":"B0025"
  },
  {
    "timestamp":1443080000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4587392/can-we-create-an-instance-of-an-interface-in-java",
    "text":"nterface in Java? \n",
    "u_id":"B0005"
  },
  {
    "timestamp":1443080000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4587392/can-we-create-an-instance-of-an-interface-in-java",
    "text":"nterface in Java? \n",
    "u_id":"B0005"
  },
  {
    "timestamp":1443080000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17077547/i-know-we-can-not-instantiate-either-an-interface-or-an-abstract-class-in-java",
    "text":"Interface has no method implemented, so there is no purpose to instantiate it as 'nothing' will happen when invoke a method Abstract class can have abstract method declaration, which is like a interface method with no implementation.\n",
    "u_id":"B0005"
  },
  {
    "timestamp":1443080000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17077547/i-know-we-can-not-instantiate-either-an-interface-or-an-abstract-class-in-java",
    "text":"You can't instantiate an interface or an abstract class because it would defy the object oriented model. \n",
    "u_id":"B0005"
  },
  {
    "timestamp":1444120000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/1795808/and-and-or-in-if-statements",
    "text":"||\n",
    "u_id":"B0005"
  },
  {
    "timestamp":1444270000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10675064/find-duplicates-of-a-vector-and-delete-preserving-the-order-of-parallel-vectors",
    "text":" for (int k = 0 ; k < vA.size() ; k++)             {                       \n",
    "u_id":"B0005"
  },
  {
    "timestamp":1442350000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=public%20static%20Product%20parseStringToProduct(String%20lineToParse)&s=706b407b-4223-4608-8fa8-cb083943f6b0",
    "text":"(String lineToParse)\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1443820000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5477241/swing-java-how-to-use-the-gettext-and-settext-string-properly",
    "text":"label1.setVisible(false);\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1444030000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2536873/how-can-i-set-size-of-a-button",
    "text":"btn.setPreferredSize(new Dimension(100, 100));\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1444770000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12178514/how-a-jpanel-displays-different-colors-from-an-array-of-colors",
    "text":"colors = new Color[]{Color.PINK, Color.GREEN, Color.BLACK, Color.RED}; \n",
    "u_id":"A0009"
  },
  {
    "timestamp":1444770000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/22089205/nullpointer-error-from-my-classes",
    "text":"currentColor = Color.black;       rectList = new ArrayList();\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1444770000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/22089205/nullpointer-error-from-my-classes",
    "text":"ColorListener listener = new ColorListener();       for (int i=0; i<colorRButtons.length; i++)\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1444770000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/22089205/nullpointer-error-from-my-classes",
    "text":"import java.awt.*; import javax.swing.*;\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1444800000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/22089205/nullpointer-error-from-my-classes",
    "text":"canvas.addMouseListener(new PointListener());       canvas.addMouseMotionListener(new PointListener());\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1444860000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/22089205/nullpointer-error-from-my-classes",
    "text":"canvas.repaint();\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1444860000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/22089205/nullpointer-error-from-my-classes",
    "text":"if (event.getSource() == colorRButtons[0])              currentColor = colors[0];\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1444860000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/22089205/nullpointer-error-from-my-classes",
    "text":"for (int i=0; i < rectList.size(); i++)             {\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1446240000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19937629/sorting-an-arraylist-into-object-type-and-then-alphabetically",
    "text":"public int compare(Food food1, Food food2) {         int result = 0;\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1446580000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5601232/finding-the-minimum-of-an-array-using-recursion",
    "text":"if (index == elements.length - 1) {     return elements[index];\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1446580000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15689097/how-do-you-recursively-count-the-number-of-negative-numbers-in-an-array-java",
    "text":"int i=0;         if(numbers[count]<0)\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1446580000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=how%20to%20find%20evenIndex%20number%20in%20an%20array",
    "text":"number in an array\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1446600000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12617021/measure-size-length-of-singly-linked-list-in-java",
    "text":" \n",
    "u_id":"A0009"
  },
  {
    "timestamp":1446600000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12617021/measure-size-length-of-singly-linked-list-in-java",
    "text":"while(CurrNode.next != null)     {\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1446770000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15958495/linked-lists-remove-element-at-an-index",
    "text":"object = iterator.next();                    iterator.remove();\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1447360000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=countHowMany%28Object+searchedObject%29",
    "text":" searchedObject\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1447980000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/33799473/writing-method-to-help-determine-postfix-notation",
    "text":"char topStack;              while(!stack1.isEmpty() && (topStack = stack1.peek()) != '('){\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1448060000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/16100036/parenthesis-error-check-for-infix-to-postfix-conversion-java",
    "text":"int v1 = 0, v2 = 0;       //find value for first\n",
    "u_id":"A0009"
  },
  {
    "timestamp":1441350000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/1678520/javac-not-working-in-windows-command-prompt",
    "text":"c:program filesjavajdk1.6.0_16injavac.exe\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441350000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/1678520/javac-not-working-in-windows-command-prompt",
    "text":" Otherwise, make sure there is a javac in that directory by trying:\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441350000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/1678520/javac-not-working-in-windows-command-prompt",
    "text":"echo %path%\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441350000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2411538/change-where-java-looks-for-javac-exe",
    "text":"C:Program FilesJavajdk1.6.0_18\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441350000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/1678520/javac-not-working-in-windows-command-prompt",
    "text":"echo %path%\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441350000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/1678520/javac-not-working-in-windows-command-prompt",
    "text":"for %i in (javac.exe) do @echo %~$PATH:i\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441410000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/1266792/how-to-change-the-default-netbeans-7-project-directory",
    "text":".netbeans7.0configPreferencesorg\netbeansmodulesprojectui.properties\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441410000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/1266792/how-to-change-the-default-netbeans-7-project-directory",
    "text":".netbeans7.0configPreferencesorg\netbeansmodulesprojectui.properties\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1441410000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/3077531/how-to-change-the-default-project-directory-folder-in-netbeans-6-9",
    "text":"projectui.properties\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1442210000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/20767732/best-way-to-extract-text-e-g-articles-from-web-page",
    "text":"different text extraction algorithms\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1442560000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10985223/java-polymorphism",
    "text":"     @Override\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1442820000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23050928/error-in-plot-new-figure-margins-too-large-scatter-plot",
    "text":"par(mar=c(1,1,1,1))\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1442820000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23050928/error-in-plot-new-figure-margins-too-large-scatter-plot",
    "text":"1 4.1 4.1 2.1\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444030000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/20795488/getting-json-data-in-soap-webservice-reponse",
    "text":"HttpResponse \n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444690000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/6081439/changing-column-names-of-a-data-frame-in-r",
    "text":" names(new\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444690000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12758075/how-to-create-dummy-variables",
    "text":"dt1 <- data.frame(year=factor(c(NA,2003:2005))) dt2 <- setNames(cbind(dt1,model.matrix(~year-1,data=dt1)),\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444690000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12758075/how-to-create-dummy-variables",
    "text":"dt1 <- data.frame(year=factor(c(NA,2003:2005)))\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444720000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12328056/how-do-i-delete-rows-in-a-data-frame",
    "text":"myData[-c(2, 4, 6), ] \n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444720000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12328056/how-do-i-delete-rows-in-a-data-frame",
    "text":"myData[-c(2, 4, 6), ] \n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444720000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12328056/how-do-i-delete-rows-in-a-data-frame",
    "text":"myData <- myData[-c(2, 4, 6), ]\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444720000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/24428051/removing-display-of-r-row-names-from-data-frame",
    "text":"rownames(df) <- NULL\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444720000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/24428051/removing-display-of-r-row-names-from-data-frame",
    "text":"rownames(df1) <- NULL\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444720000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/13520515/command-to-remove-row-from-a-data-frame",
    "text":"  Possible Duplicate:\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444720000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/7541610/how-to-delete-a-row-in-r",
    "text":"df = df[-1,]\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444720000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/7541610/how-to-delete-a-row-in-r",
    "text":"df = df[-1,]\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444720000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/7541610/how-to-delete-a-row-in-r",
    "text":"df$x = NULL\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444870000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/6088798/what-is-the-best-way-to-determine-what-jradiobutton-is-selected",
    "text":" for (int i = 0, n = buttons.length; i < n; i++) {      \n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444870000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/6088798/what-is-the-best-way-to-determine-what-jradiobutton-is-selected",
    "text":" for (int i = 0, n = buttons.length; i < n; i++) {      \n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444870000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/6088798/what-is-the-best-way-to-determine-what-jradiobutton-is-selected",
    "text":"for (int i = 0, n = buttons.length; i < n; i++) {         if (buttons[i].isSelected()) {\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444870000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/6088798/what-is-the-best-way-to-determine-what-jradiobutton-is-selected",
    "text":"for (int i = 0, n = buttons.length; i < n; i++) {         if (buttons[i].isSelected()) {\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444870000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/6088798/what-is-the-best-way-to-determine-what-jradiobutton-is-selected",
    "text":"return buttons.length + 1;\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444880000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/201287/how-do-i-get-which-jradiobutton-is-selected-from-a-buttongroup",
    "text":"for (Enumeration<AbstractButton> buttons = buttonGroup.getElements(); buttons.hasMoreElements();) {             AbstractButton button = buttons.nextElement();\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444880000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/201287/how-do-i-get-which-jradiobutton-is-selected-from-a-buttongroup",
    "text":"on(\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444880000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/201287/how-do-i-get-which-jradiobutton-is-selected-from-a-buttongroup",
    "text":"Group.getSelection().getActionCommand()\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444870000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2615522/java-bufferedimage-getting-red-green-and-blue-individually/2615530#2615530",
    "text":"Color c = new Color(image.getRGB());\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444870000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2615522/java-bufferedimage-getting-red-green-and-blue-individually/2615530#2615530",
    "text":"Color c = new Color(image.getRGB()); int red = c.getRed();\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444880000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/25207419/switch-statement-quotes",
    "text":"switch(what) {         case '1': break;\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=merge%20sort",
    "text":" Search\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=merge%20sort",
    "text":" Search\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445120000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/11002766/changing-reference-group-for-categorical-predictor-variable-in-logistic-regressi",
    "text":"DF$fct <- C(DF$fct, contr.treatment, base=3)\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445120000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/11002766/changing-reference-group-for-categorical-predictor-variable-in-logistic-regressi",
    "text":"library(Hmisc) \n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445120000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/11002766/changing-reference-group-for-categorical-predictor-variable-in-logistic-regressi",
    "text":"dd=datadist(df)\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445120000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/11002766/changing-reference-group-for-categorical-predictor-variable-in-logistic-regressi",
    "text":"options(datadist='dd')\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445120000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/11002766/changing-reference-group-for-categorical-predictor-variable-in-logistic-regressi",
    "text":"options(datadist='dd') (m=lrm(y ~ catvar, data=df))\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445120000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/11002766/changing-reference-group-for-categorical-predictor-variable-in-logistic-regressi",
    "text":"summary(m, catvar=3)\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445280000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/18985867/convert-json-format-to-xml-format",
    "text":"Return xml.ToString()\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445270000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/814001/convert-json-string-to-xml-or-xml-to-json-string",
    "text":"// To convert JSON text contained in string json into an XML node XmlDocument doc = JsonConvert.DeserializeXmlNode(json);\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445280000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/814001/convert-json-string-to-xml-or-xml-to-json-string",
    "text":"// To convert JSON text contained in string json into an XML node XmlDocument doc = JsonConvert.DeserializeXmlNode(json);\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445280000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/814001/convert-json-string-to-xml-or-xml-to-json-string",
    "text":"XmlDocument doc = JsonConvert.DeserializeXmlNode(json);\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445280000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/814001/convert-json-string-to-xml-or-xml-to-json-string",
    "text":"XmlDocument doc = JsonConvert.DeserializeXmlNode(json);\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445280000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/814001/convert-json-string-to-xml-or-xml-to-json-string",
    "text":"t.DeserializeXmlNode(json);\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445280000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4611031/convert-json-string-to-c-sharp-object",
    "text":"vaScriptSerializ\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445300000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/16640962/convert-string-to-xml-using-net",
    "text":"ument.Parse(s)\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445300000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/16640962/convert-string-to-xml-using-net",
    "text":"ument.Parse(s)\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445300000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/16640962/convert-string-to-xml-using-net",
    "text":"XDocument.Parse(s)\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445300000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/16640962/convert-string-to-xml-using-net",
    "text":"XDocument.Parse(s)\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445300000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10946888/how-to-convert-string-to-xml-using-c-sharp",
    "text":"xDoc.LoadXml(xml);\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445300000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10946888/how-to-convert-string-to-xml-using-c-sharp",
    "text":"xDoc.LoadXml(xml);\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445320000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17432142/plot-the-observed-and-fitted-values-from-a-linear-regression-using-xyplot-from",
    "text":"t$\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445320000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17432142/plot-the-observed-and-fitted-values-from-a-linear-regression-using-xyplot-from",
    "text":"t$\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445320000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17432142/plot-the-observed-and-fitted-values-from-a-linear-regression-using-xyplot-from",
    "text":"at$\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445320000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17432142/plot-the-observed-and-fitted-values-from-a-linear-regression-using-xyplot-from",
    "text":"at$\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445320000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17432142/plot-the-observed-and-fitted-values-from-a-linear-regression-using-xyplot-from",
    "text":" dat\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445320000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17432142/plot-the-observed-and-fitted-values-from-a-linear-regression-using-xyplot-from",
    "text":" dat\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445320000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17432142/plot-the-observed-and-fitted-values-from-a-linear-regression-using-xyplot-from",
    "text":"at$y,\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445320000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17432142/plot-the-observed-and-fitted-values-from-a-linear-regression-using-xyplot-from",
    "text":"at$y,\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445320000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17432142/plot-the-observed-and-fitted-values-from-a-linear-regression-using-xyplot-from",
    "text":"dat$y\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445320000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17432142/plot-the-observed-and-fitted-values-from-a-linear-regression-using-xyplot-from",
    "text":"dat$y\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445320000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17432142/plot-the-observed-and-fitted-values-from-a-linear-regression-using-xyplot-from",
    "text":"res <- stack(data.frame(Observed = dat$y, Predicted = fitted(mod)))\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1445320000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17432142/plot-the-observed-and-fitted-values-from-a-linear-regression-using-xyplot-from",
    "text":"res <- stack(data.frame(Observed = dat$y, Predicted = fitted(mod))) res <- cbind(res, x = rep(dat$x, 2))\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1446230000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4605206/drop-columns-in-r-data-frame",
    "text":"DF[,!(names(DF) %in% drops)\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1446450000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19937629/sorting-an-arraylist-into-object-type-and-then-alphabetically",
    "text":"[]>(); Collections.sort(list, new Comparator<String[]>() { public int compare(String[] o1, String[] o2)\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1446450000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19937629/sorting-an-arraylist-into-object-type-and-then-alphabetically",
    "text":"[]>(); Collections.sort(list, new Comparator<String[]>() { public int compare(String[] o1, String[] o2)\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1446450000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19937629/sorting-an-arraylist-into-object-type-and-then-alphabetically",
    "text":"e saying, but I want to clarify: you can pass String[] to compare. ArrayList<String[]> list = new ArrayList<String[]>(); Collections\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1446450000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19937629/sorting-an-arraylist-into-object-type-and-then-alphabetically",
    "text":"e saying, but I want to clarify: you can pass String[] to compare. ArrayList<String[]> list = new ArrayList<String[]>(); Collections\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1446460000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14475556/how-to-sort-arraylist-of-objects",
    "text":"Collections.sort(players, new Comparator<Team>() {         @Override public int compare(Team p1, Team p2) {\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1446460000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14475556/how-to-sort-arraylist-of-objects",
    "text":"Collections.sort(players, new Comparator<Team>() {         @Override public int compare(Team p1, Team p2) {\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1446680000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5391124/in-r-select-rows-of-a-matrix-that-meet-a-condition",
    "text":"m[m[,3] == 11,]\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1446690000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/21283148/substring-of-all-data-frame-elements",
    "text":"sapply(x, substring, 2, 4)\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1446690000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/21283148/substring-of-all-data-frame-elements",
    "text":"substring(x[,1], 2, 4) \n",
    "u_id":"A0074"
  },
  {
    "timestamp":1446690000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19692672/remove-all-punctuation-from-a-csv-after-importing-it",
    "text":"nct:]]\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1446770000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4605206/drop-columns-in-r-data-frame",
    "text":"df <- df[ -c(1,3:6, 12) ]\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1446800000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=solve%20recursive",
    "text":"Google Foobar\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1446800000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=solve%20recursive",
    "text":"Google Foobar\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1446840000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/18514694/how-to-save-a-data-frame-in-a-txt-or-excel-file-separated-by-columns",
    "text":"write.csv(df, 'test2.csv')\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1446840000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/8420288/r-how-can-i-delete-rows-if-an-element-in-a-row-satisfies-certain-characteristic",
    "text":"mm2 <- mm[mm[,1]!=2,]\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1446840000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/8420288/r-how-can-i-delete-rows-if-an-element-in-a-row-satisfies-certain-characteristic",
    "text":"mm2 <- mm[mm[,1]!=2,]\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1446840000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/8420288/r-how-can-i-delete-rows-if-an-element-in-a-row-satisfies-certain-characteristic",
    "text":"mm2 <- mm[mm[,1]!=2,]\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1446840000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/8420288/r-how-can-i-delete-rows-if-an-element-in-a-row-satisfies-certain-characteristic",
    "text":"mm2 <- mm[mm[,1]!=2,]\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1447120000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/24774399/syntax-to-move-backwards-in-linkedlist",
    "text":"ListIterator<Foo> iterator = list.listIterator(list.size()); while (iterator.hasPrevious()) {\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1447400000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5236486/adding-items-to-end-of-linked-list",
    "text":"// save the reference to the header so we can return it.        Node ret = header;\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1447890000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/18306362/run-r-script-from-command-line",
    "text":"Rscript a.R\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1448000000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15331637/convert-string-to-arraylist-character-in-java",
    "text":"ArrayList<Character> chars = new ArrayList<Character>(); for (char c : str.toCharArray()) {\n",
    "u_id":"A0074"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=3%20partition%20merge%20sort",
    "text":"3 partition \n",
    "u_id":"A0075"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2571049/how-to-sort-in-place-using-the-merge-sort-algorithm",
    "text":"omparisons. This is the\n",
    "u_id":"A0087"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2571049/how-to-sort-in-place-using-the-merge-sort-algorithm",
    "text":"s relevant too. I have a printout of it lying around, passed on to me by a colleague, but I haven't read it. It seems to cover basic theory, but I'm not familiar enough with th\n",
    "u_id":"A0087"
  },
  {
    "timestamp":1446850000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10618722/how-to-put-throws-ioexception-to-the-statement",
    "text":"1: error: unreported exception IOException; must be caught or declared to be thrown                     HighestScoreFile.HighestScoreFile(input, hours, minutes, seco\n",
    "u_id":"A0087"
  },
  {
    "timestamp":1446850000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10618722/how-to-put-throws-ioexception-to-the-statement",
    "text":"        \n",
    "u_id":"A0087"
  },
  {
    "timestamp":1446850000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10618722/how-to-put-throws-ioexception-to-the-statement",
    "text":"ighest.txt. \n",
    "u_id":"A0087"
  },
  {
    "timestamp":1446850000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10618722/how-to-put-throws-ioexception-to-the-statement",
    "text":"ighest.txt. \n",
    "u_id":"A0087"
  },
  {
    "timestamp":1446850000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10618722/how-to-put-throws-ioexception-to-the-statement",
    "text":"ighest.txt. \n",
    "u_id":"A0087"
  },
  {
    "timestamp":1446850000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10618722/how-to-put-throws-ioexception-to-the-statement",
    "text":"ighest.txt. \n",
    "u_id":"A0087"
  },
  {
    "timestamp":1446850000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10618722/how-to-put-throws-ioexception-to-the-statement",
    "text":"ighest.txt. \n",
    "u_id":"A0087"
  },
  {
    "timestamp":1446850000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10618722/how-to-put-throws-ioexception-to-the-statement",
    "text":"ighest.txt. \n",
    "u_id":"A0087"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/29436091/recursive-merge-sort",
    "text":"import java.util.Arrays; \n",
    "u_id":"A0059"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/29436091/recursive-merge-sort",
    "text":"import java.util.Arrays; \n",
    "u_id":"A0059"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/29436091/recursive-merge-sort",
    "text":"import java.util.Arrays; \n",
    "u_id":"A0059"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/29436091/recursive-merge-sort",
    "text":"list.length - mid\n",
    "u_id":"A0059"
  },
  {
    "timestamp":1445530000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9723912/reversing-a-string-with-recursion-in-java",
    "text":"public static String reverse(String str) {     if ((null == str) || (str.length() <= 1)) {\n",
    "u_id":"A0059"
  },
  {
    "timestamp":1446010000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2560368/what-is-the-use-of-printstacktrace-method-in-java",
    "text":"t very useful tool for diagnosing an Exception. It tells you what happened and where in the code this hap\n",
    "u_id":"A0059"
  },
  {
    "timestamp":1447460000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12678781/reversing-an-array-in-java",
    "text":"for (i = 0; i < array.length / 2; i++) {   int temp = array[i];\n",
    "u_id":"A0059"
  },
  {
    "timestamp":1442560000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/153724/how-to-round-a-number-to-n-decimal-places-in-java",
    "text":"technique\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444000000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17845048/java-centering-a-component-inside-gridlayout",
    "text":"ponent of the matrix (GridLayout) stays centered instead of displaying at the left and with different size, how can I do that?\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444000000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17845048/java-centering-a-component-inside-gridlayout",
    "text":"ponent of the matrix (GridLayout) stays centered instead of displaying at the left and with different size, how can I do that?\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444000000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17845048/java-centering-a-component-inside-gridlayout",
    "text":"e matrix (GridLayout) stays centered instead of displaying at the left and with different size, how can I do that?\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444000000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17845048/java-centering-a-component-inside-gridlayout",
    "text":"e matrix (GridLayout) stays centered instead of displaying at the left and with different size, how can I do that?\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444000000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17845048/java-centering-a-component-inside-gridlayout",
    "text":" matrix (\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444000000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17845048/java-centering-a-component-inside-gridlayout",
    "text":"GridLayout\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444000000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17845048/java-centering-a-component-inside-gridlayout",
    "text":" \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444000000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17845048/java-centering-a-component-inside-gridlayout",
    "text":"And I want that each component of the matrix (GridLayout) stays centered instead of displaying at the left and with different size, how can I do that? \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444000000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17845048/java-centering-a-component-inside-gridlayout",
    "text":"And I want that each component of the matrix (GridLayout) stays centered instead of displaying at the left and with different size, how can I do that? \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444000000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17845048/java-centering-a-component-inside-gridlayout",
    "text":"mponent(Or more if you want them right next to each other) In a JPanel that is using FlowLayout(the default Layout manager) and then add those JPanels to the JFrame. The JPanels adjust to the GridLayout but the com\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444000000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17845048/java-centering-a-component-inside-gridlayout",
    "text":"mponent(Or more if you want them right next to each other) In a JPanel that is using FlowLayout(the default Layout manager) and then add those JPanels to the JFrame. The JPanels adjust to the GridLayout but the com\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444000000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17845048/java-centering-a-component-inside-gridlayout",
    "text":"components \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444000000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17845048/java-centering-a-component-inside-gridlayout",
    "text":"ent(Or more if you want them right next to each other) In a JPanel that is using FlowLayout(the default Layout manager) and then add those JPanels to the JFrame. The JPanels adjust to the GridLayout but the com\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444000000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17845048/java-centering-a-component-inside-gridlayout",
    "text":"ent(Or more if you want them right next to each other) In a JPanel that is using FlowLayout(the default Layout manager) and then add those JPanels to the JFrame. The JPanels adjust to the GridLayout but the com\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444000000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17845048/java-centering-a-component-inside-gridlayout",
    "text":"components \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444000000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17845048/java-centering-a-component-inside-gridlayout",
    "text":"To center them I'd put each component(Or more if you want them right next to each other) In a JPanel that is using FlowLayout(the default Layout manager) and then add those JPanels to the JFrame. The JPanels adjust to the GridLayout but the components on the JPanels stay in the same position. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444000000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17845048/java-centering-a-component-inside-gridlayout",
    "text":"To center them I'd put each component(Or more if you want them right next to each other) In a JPanel that is using FlowLayout(the default Layout manager) and then add those JPanels to the JFrame. The JPanels adjust to the GridLayout but the components on the JPanels stay in the same position. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444000000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/370310/java-get-jpanel-components",
    "text":"n Java is also an AWT container. Thus, you should be able to use getComponents to get the array of contained components in the panel, iterate over them, check their types (To make sure you didn't get other controls), and do whatever you need with them. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444000000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/370310/java-get-jpanel-components",
    "text":"n Java is also an AWT container. Thus, you should be able to use getComponents to get the array of contained components in the panel, iterate over them, check their types (To make sure you didn't get other controls), and do whatever you need with them. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444000000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/370310/java-get-jpanel-components",
    "text":"with \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444000000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/370310/java-get-jpanel-components",
    "text":" up vote\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444000000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/370310/java-get-jpanel-components",
    "text":"is also an AWT container. Thus, you should be able to use getComponents to get the array of contained components in the panel, iterate over them, check their types (To make sure you didn't get other controls), and do whatever you need with them. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444000000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/370310/java-get-jpanel-components",
    "text":"is also an AWT container. Thus, you should be able to use getComponents to get the array of contained components in the panel, iterate over them, check their types (To make sure you didn't get other controls), and do whatever you need with them. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444000000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/370310/java-get-jpanel-components",
    "text":"is also an AWT container. Thus, you should be able to use getComponents to get the array of contained components in the panel, iterate over them, check their types (To make sure you didn't get other controls), and do whatever you need with them. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444000000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/370310/java-get-jpanel-components",
    "text":"is also an AWT container. Thus, you should be able to use getComponents to get the array of contained components in the panel, iterate over them, check their types (To make sure you didn't get other controls), and do whatever you need with them. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444010000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14032757/empty-string-validation-for-multiple-jtextfield",
    "text":"er which contains the validation logic. Here it's simply checking for empty text in the field in verify. Note that verify must not have side-effects\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444010000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14032757/empty-string-validation-for-multiple-jtextfield",
    "text":"er which contains the validation logic. Here it's simply checking for empty text in the field in verify. Note that verify must not have side-effects\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444010000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14032757/empty-string-validation-for-multiple-jtextfield",
    "text":"which contains the validation logic. Here it's simply checking for empty text in the field in verify. Note that verify must not have side-effects\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444010000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14032757/empty-string-validation-for-multiple-jtextfield",
    "text":"which contains the validation logic. Here it's simply checking for empty text in the field in verify. Note that verify must not have side-effects\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444010000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14032757/empty-string-validation-for-multiple-jtextfield",
    "text":"which \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444010000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14032757/empty-string-validation-for-multiple-jtextfield",
    "text":" which contains the validation logic. Here it's simply checking for empty text in the field in verify. Note that verify must not have side-effects\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444010000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14032757/empty-string-validation-for-multiple-jtextfield",
    "text":" which contains the validation logic. Here it's simply checking for empty text in the field in verify. Note that verify must not have side-effects\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444010000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14032757/empty-string-validation-for-multiple-jtextfield",
    "text":"simply \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444010000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14032757/empty-string-validation-for-multiple-jtextfield",
    "text":"ns the validation logic. Here it's simply checking for empty text in the field in verify. Note that verify must not have side-effects\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444010000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14032757/empty-string-validation-for-multiple-jtextfield",
    "text":"ns the validation logic. Here it's simply checking for empty text in the field in verify. Note that verify must not have side-effects\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444010000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14032757/empty-string-validation-for-multiple-jtextfield",
    "text":"v\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444010000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14032757/empty-string-validation-for-multiple-jtextfield",
    "text":"ntains the validation logic. Here it's simply checking for empty text in the field in verify. Note that verify must not have side-effects\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444010000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14032757/empty-string-validation-for-multiple-jtextfield",
    "text":"ntains the validation logic. Here it's simply checking for empty text in the field in verify. Note that verify must not have side-effects\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444010000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14032757/empty-string-validation-for-multiple-jtextfield",
    "text":"contains \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444010000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/370310/java-get-jpanel-components",
    "text":"for (int i = 0; i < components.length; i++) { \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444010000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/370310/java-get-jpanel-components",
    "text":"for (int i = 0; i < components.length; i++) { \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444010000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/370310/java-get-jpanel-components",
    "text":"setEnabled\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444010000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/370310/java-get-jpanel-components",
    "text":" \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444020000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/370310/java-get-jpanel-components",
    "text":" components in the panel, iterate over them, check their types (To make sure you didn't get other controls), and do whatever you need with them. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444020000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/370310/java-get-jpanel-components",
    "text":" components in the panel, iterate over them, check their types (To make sure you didn't get other controls), and do whatever you need with them. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444030000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14443259/one-action-listener-two-jbuttons",
    "text":"n is clicked. However I want different actions to happen when each are clicked. How can I distinguish, i\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444030000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14443259/one-action-listener-two-jbuttons",
    "text":"n is clicked. However I want different actions to happen when each are clicked. How can I distinguish, i\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4262669/refresh-jlist-in-a-jframe",
    "text":"ng the Vector. Changes should be made directly to the ListModel then the table will repaint itself automatically. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4262669/refresh-jlist-in-a-jframe",
    "text":"ng the Vector. Changes should be made directly to the ListModel then the table will repaint itself automatically. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4262669/refresh-jlist-in-a-jframe",
    "text":"ListModel \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4262669/refresh-jlist-in-a-jframe",
    "text":"If you decide to recreate the ListModel because of the changes to the Vector, then you update the list by doing: \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4262669/refresh-jlist-in-a-jframe",
    "text":"g the Vector. Changes should be made directly to the ListModel then the table will repaint itself automatically. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4262669/refresh-jlist-in-a-jframe",
    "text":"g the Vector. Changes should be made directly to the ListModel then the table will repaint itself automatically. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4262669/refresh-jlist-in-a-jframe",
    "text":"ListModel \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4262669/refresh-jlist-in-a-jframe",
    "text":"You should not be updating the Vector. Changes should be made directly to the ListModel then the table will repaint itself automatically. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4262669/refresh-jlist-in-a-jframe",
    "text":"You should not be updating the Vector. Changes should be made directly to the ListModel then the table will repaint itself automatically. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4262669/refresh-jlist-in-a-jframe",
    "text":"updating \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4262669/refresh-jlist-in-a-jframe",
    "text":"updating \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4262669/refresh-jlist-in-a-jframe",
    "text":"updating \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/30089150/java-vector-class-not-updating",
    "text":"ram for an intro level Java class, and am having an issue when using Vector to dynamically display data to a GUI. We're storing data in a linked list and using the vector to have a dynamic list showing the data members on the side of the GUI. We can add and remove data from the linked list just fine, and when we add to it, the vector automatically updates (we have a call to do that at the end of every successful add and remove). However, when we successfully remove a data member from the linked list, the data stays on the Jlist that the vector is being displayed on. We are required to use vector and cannot use a generic ArrayList.\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/30089150/java-vector-class-not-updating",
    "text":"ram for an intro level Java class, and am having an issue when using Vector to dynamically display data to a GUI. We're storing data in a linked list and using the vector to have a dynamic list showing the data members on the side of the GUI. We can add and remove data from the linked list just fine, and when we add to it, the vector automatically updates (we have a call to do that at the end of every successful add and remove). However, when we successfully remove a data member from the linked list, the data stays on the Jlist that the vector is being displayed on. We are required to use vector and cannot use a generic ArrayList.\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/30089150/java-vector-class-not-updating",
    "text":"am for an intro level Java class, and am having an issue when using Vector to dynamically display data to a GUI. We're storing data in a linked list and using the vector to have a dynamic list showing the data members on the side of the GUI. We can add and remove data from the linked list just fine, and when we add to it, the vector automatically updates (we have a call to do that at the end of every successful add and remove). However, when we successfully remove a data member from the linked list, the data stays on the Jlist that the vector is being displayed on. We are required to use vector and cannot use a generic ArrayList.\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/30089150/java-vector-class-not-updating",
    "text":"am for an intro level Java class, and am having an issue when using Vector to dynamically display data to a GUI. We're storing data in a linked list and using the vector to have a dynamic list showing the data members on the side of the GUI. We can add and remove data from the linked list just fine, and when we add to it, the vector automatically updates (we have a call to do that at the end of every successful add and remove). However, when we successfully remove a data member from the linked list, the data stays on the Jlist that the vector is being displayed on. We are required to use vector and cannot use a generic ArrayList.\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/30089150/java-vector-class-not-updating",
    "text":"data \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/30089150/java-vector-class-not-updating",
    "text":" \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/30089150/java-vector-class-not-updating",
    "text":"vector \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/30089150/java-vector-class-not-updating",
    "text":"we're using the vector only because our professor told us to :/ but the we use the setListData method inJList to set it to the data in the vector ̢�������� user3458030 May 7 at 0:27 \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/30089150/java-vector-class-not-updating",
    "text":"we're using the vector only because our professor told us to :/ but the we use the setListData method inJList to set it to the data in the vector ̢�������� user3458030 May 7 at 0:27 \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/30089150/java-vector-class-not-updating",
    "text":"we're using the vector only because our professor told us to :/ but the we use the setListData method inJList to set it to the data in the vector ̢�������� user3458030 May 7 at 0:27 \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/30089150/java-vector-class-not-updating",
    "text":" \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/30089150/java-vector-class-not-updating",
    "text":"we're using the vector only because our professor told us to :/ but the we use the setListData method inJList to set it to the data in the vector ̢�������� user3458030 May 7 at 0:27 \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/30089150/java-vector-class-not-updating",
    "text":"we're using the vector only because our professor told us to :/ but the we use the setListData method inJList to set it to the data in the vector ̢�������� user3458030 May 7 at 0:27 \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/30089150/java-vector-class-not-updating",
    "text":"we're using the vector only because our professor told us to :/ but the we use the setListData method inJList to set it to the data in the vector ̢�������� user3458030 May 7 at 0:27 \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/30089150/java-vector-class-not-updating",
    "text":"py the values out of the vector once and never read it again. This means changes to the vector will not be reflected in the JList.\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/30089150/java-vector-class-not-updating",
    "text":"py the values out of the vector once and never read it again. This means changes to the vector will not be reflected in the JList.\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/30089150/java-vector-class-not-updating",
    "text":" \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/30089150/java-vector-class-not-updating",
    "text":"Assuming your JList is backed by a Vector (by using the JList(Vector<?> listData) constructor), the JList will copy the values out of the vector once and never read it again. This means changes to the vector will not be reflected in the JList. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/30089150/java-vector-class-not-updating",
    "text":"Assuming your JList is backed by a Vector (by using the JList(Vector<?> listData) constructor), the JList will copy the values out of the vector once and never read it again. This means changes to the vector will not be reflected in the JList. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/30089150/java-vector-class-not-updating",
    "text":"the \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/30089150/java-vector-class-not-updating",
    "text":".\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/30089150/java-vector-class-not-updating",
    "text":"values out of the vector once and never read it again. This means changes to the vector will not be reflected in the JList. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/30089150/java-vector-class-not-updating",
    "text":"values out of the vector once and never read it again. This means changes to the vector will not be reflected in the JList. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/30089150/java-vector-class-not-updating",
    "text":"the \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/30089150/java-vector-class-not-updating",
    "text":"update \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/30089150/java-vector-class-not-updating",
    "text":"update \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444150000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/24939192/add-jscrollpane-to-jtextarea",
    "text":" scroll1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444150000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/24939192/add-jscrollpane-to-jtextarea",
    "text":" scroll1.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS);\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444690000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/215497/in-java-whats-the-difference-between-public-default-protected-and-private",
    "text":"In\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444720000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2585650/variable-cannot-be-resolved",
    "text":" two local variables i who goes out of scope immediately after they're declared and initialized. If j n\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444720000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2585650/variable-cannot-be-resolved",
    "text":" two local variables i who goes out of scope immediately after they're declared and initialized. If j n\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444720000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2585650/variable-cannot-be-resolved",
    "text":" two local variables i who goes out of scope immediately after they're declared and initialized. If j needs\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1444720000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2585650/variable-cannot-be-resolved",
    "text":" two local variables i who goes out of scope immediately after they're declared and initialized. If j needs\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1445910000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/1625234/how-to-append-text-to-an-existing-file-in-java",
    "text":"How \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1445910000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/1625234/how-to-append-text-to-an-existing-file-in-java",
    "text":"How \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1447460000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5714053/how-can-we-redirect-eclipse-console-output-to-a-file",
    "text":"rintStream) and System.setErr(PrintStream). The problem with 1) is that I need to record console output to different files instead of one file.\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1447460000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5714053/how-can-we-redirect-eclipse-console-output-to-a-file",
    "text":"rintStream) and System.setErr(PrintStream). The problem with 1) is that I need to record console output to different files instead of one file.\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1447460000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5714053/how-can-we-redirect-eclipse-console-output-to-a-file",
    "text":"t I need to record console output to different files instead of one file. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1447460000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5714053/how-can-we-redirect-eclipse-console-output-to-a-file",
    "text":"t I need to record console output to different files instead of one file. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1447460000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5714053/how-can-we-redirect-eclipse-console-output-to-a-file",
    "text":"that I need to record console output to different files instead of one file. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1447460000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5714053/how-can-we-redirect-eclipse-console-output-to-a-file",
    "text":"that I need to record console output to different files instead of one file. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1447460000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5714053/how-can-we-redirect-eclipse-console-output-to-a-file",
    "text":"hat I need to record console output to different files instead of one file. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1447460000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5714053/how-can-we-redirect-eclipse-console-output-to-a-file",
    "text":"hat I need to record console output to different files instead of one file. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1447460000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5714053/how-can-we-redirect-eclipse-console-output-to-a-file",
    "text":"at I need to record console output to different files instead of one file. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1447460000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5714053/how-can-we-redirect-eclipse-console-output-to-a-file",
    "text":"at I need to record console output to different files instead of one file. \n",
    "u_id":"A0047"
  },
  {
    "timestamp":1447540000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19592846/how-to-check-if-a-string-contain-any-of-operator-in-java",
    "text":"ks if the string contains a specified sequence of char values String.indexOf() - which returns the index within the string of the first occurence of the specified character or substring (there are 4 variations of this method)\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1447540000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19592846/how-to-check-if-a-string-contain-any-of-operator-in-java",
    "text":"ks if the string contains a specified sequence of char values String.indexOf() - which returns the index within the string of the first occurence of the specified character or substring (there are 4 variations of this method)\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1447540000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19592846/how-to-check-if-a-string-contain-any-of-operator-in-java",
    "text":"hecks if the string contains a specified sequence of char values String.indexOf() - which returns the index within the string of the first occurence of the specified character or substring (there are 4 variations of this method)\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1447540000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19592846/how-to-check-if-a-string-contain-any-of-operator-in-java",
    "text":"hecks if the string contains a specified sequence of char values String.indexOf() - which returns the index within the string of the first occurence of the specified character or substring (there are 4 variations of this method)\n",
    "u_id":"A0047"
  },
  {
    "timestamp":1447470000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/33698124/how-to-reverse-a-certain-number-of-objects-in-a-linked-list",
    "text":"  \n",
    "u_id":"A0065"
  },
  {
    "timestamp":1444070000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10274750/java-swing-setting-margins-on-textarea-with-line-border",
    "text":"400, 200); aboutArea.setBorder(border);\n",
    "u_id":"A0033"
  },
  {
    "timestamp":1444070000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10274750/java-swing-setting-margins-on-textarea-with-line-border",
    "text":"Border border = BorderFactory.createLineBorder(Color.BLACK); \n",
    "u_id":"A0033"
  },
  {
    "timestamp":1444070000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10274750/java-swing-setting-margins-on-textarea-with-line-border",
    "text":"Border border = BorderFactory.createLineBorder(Color.BLACK); \n",
    "u_id":"A0033"
  },
  {
    "timestamp":1444070000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10274750/java-swing-setting-margins-on-textarea-with-line-border",
    "text":"border \n",
    "u_id":"A0033"
  },
  {
    "timestamp":1445980000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/8965006/java-recursive-fibonacci-sequence",
    "text":"public int fibonacci(int n)  {     if(n == 0)\n",
    "u_id":"A0033"
  },
  {
    "timestamp":1446770000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9929321/converting-arraylist-to-array-in-java",
    "text":"String []dsf = new String[al.size()]; al.toArray(dsf);\n",
    "u_id":"A0033"
  },
  {
    "timestamp":1446770000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9929321/converting-arraylist-to-array-in-java",
    "text":"String []dsf = new String[al.size()]; al.toArray(dsf);\n",
    "u_id":"A0033"
  },
  {
    "timestamp":1448060000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/21696784/how-to-declare-an-arraylist-with-values",
    "text":"List\n",
    "u_id":"A0033"
  },
  {
    "timestamp":1440800000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=while%20printing%20multiple%20times&s=9d988445-d3ec-4bb8-93db-8c7a746293bd",
    "text":" \n",
    "u_id":"B0007"
  },
  {
    "timestamp":1440800000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/27078905/java-where-to-print-out-an-integer-outside-of-while-loop",
    "text":"em with your solution i\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1440800000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/27078905/java-where-to-print-out-an-integer-outside-of-while-loop",
    "text":"o\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1442510000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=java%20utility%20class&s=3fdd60e5-a549-4945-adc8-e17ce0b8fcb1",
    "text":"java utility class\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1442510000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2379221/java-currency-number-format",
    "text":"NumberFormat formatter = NumberFormat.getCurrencyInstance();\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1442540000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9189926/java-percentage-to-show-decimals",
    "text":"NumberFormat numberFormat = NumberFormat.getNumberInstance(); numberFormat.setMinimumFractionDigits(3);\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1442540000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9189926/java-percentage-to-show-decimals",
    "text":"numberFormat.setMinimumFractionDigits(3);\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1442550000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/1128723/how-can-i-test-if-an-array-contains-a-certain-value",
    "text":"Arrays.asList(yourArray).contains(yourValue)\n",
    "u_id":"B0007"
  },
  {
    "timestamp":1442370000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=currency%20format&s=99831671-c1a4-4d75-a46e-bba1669c9e33",
    "text":"ncy Format Please help\n",
    "u_id":"A0054"
  },
  {
    "timestamp":1442370000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=currency%20format&s=99831671-c1a4-4d75-a46e-bba1669c9e33",
    "text":"ncy Format Please help\n",
    "u_id":"A0054"
  },
  {
    "timestamp":1444160000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12021249/adding-jpanel-from-another-class-to-jpanel-in-jframe-begginer-java-programmer",
    "text":" \n",
    "u_id":"A0054"
  },
  {
    "timestamp":1444160000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12021249/adding-jpanel-from-another-class-to-jpanel-in-jframe-begginer-java-programmer",
    "text":" \n",
    "u_id":"A0054"
  },
  {
    "timestamp":1444240000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/3268383/java-refreshing-an-array-into-jlist",
    "text":"ate. \n",
    "u_id":"A0054"
  },
  {
    "timestamp":1444240000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/3268383/java-refreshing-an-array-into-jlist",
    "text":"ate. \n",
    "u_id":"A0054"
  },
  {
    "timestamp":1446400000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15963549/arraylist-swap-elements",
    "text":"Collections.swap(List<?> list, int i, int j);\n",
    "u_id":"A0054"
  },
  {
    "timestamp":1445040000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/22089205/nullpointer-error-from-my-classes",
    "text":"currentColor = Color.black;       rectList = new ArrayList();\n",
    "u_id":"A0088"
  },
  {
    "timestamp":1445040000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/22089205/nullpointer-error-from-my-classes",
    "text":"ColorListener listener = new ColorListener();\n",
    "u_id":"A0088"
  },
  {
    "timestamp":1445040000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/22089205/nullpointer-error-from-my-classes",
    "text":"anvas.addMouseListener(new PointListener());       canvas.addMouseMotionListener(new PointListener());\n",
    "u_id":"A0088"
  },
  {
    "timestamp":1445040000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/22089205/nullpointer-error-from-my-classes",
    "text":"anvas.addMouseListener(new PointListener());       canvas.addMouseMotionListener(new PointListener());\n",
    "u_id":"A0088"
  },
  {
    "timestamp":1445040000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/22089205/nullpointer-error-from-my-classes",
    "text":" I was given this code by my professor and it should run as is. I compile it and get the following error.\n",
    "u_id":"A0088"
  },
  {
    "timestamp":1445040000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/22089205/nullpointer-error-from-my-classes",
    "text":" I was given this code by my professor and it should run as is. I compile it and get the following error.\n",
    "u_id":"A0088"
  },
  {
    "timestamp":1445040000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/22089205/nullpointer-error-from-my-classes",
    "text":"      canvas.addMouseListener(new PointListener());       canvas.addMouseMotionListener(new PointListener());\n",
    "u_id":"A0088"
  },
  {
    "timestamp":1442550000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=linetoparse%20java",
    "text":"String lineToParse\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1442550000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=linetoparse%20java",
    "text":"String lineToParse\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1442550000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/21467462/how-to-parse-bank-information-into-particular-format-plus-java-questions/21467514#21467514",
    "text":"neToPa\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1442550000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=linetoparse%20java",
    "text":" parsing rarely comes up and it's never given a full ̢����_ explanation. I've looked through the java api documentation a few times and I never understand what it's saying, so I hope someone isn't too frustrated as to explain how to do it. The class is: BankParser ̢����_\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1442550000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=linetoparse%20java",
    "text":"CSE 205 at ASU\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1442550000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=linetoparse%20java",
    "text":"CSE 205 at ASU\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1442550000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/21467462/how-to-parse-bank-information-into-particular-format-plus-java-questions",
    "text":" lineToParse.\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1442550000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/21467462/how-to-parse-bank-information-into-particular-format-plus-java-questions",
    "text":" lineToParse.\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1442550000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/21467462/how-to-parse-bank-information-into-particular-format-plus-java-questions",
    "text":"lineToParse\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1442550000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/8860343/defining-a-type-cast-in-java",
    "text":"int)\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1442550000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/21952750/how-to-cast-string-with-decimala-bc-to-intabc-in-java",
    "text":"Double.parseDouble\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1442550000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/21952750/how-to-cast-string-with-decimala-bc-to-intabc-in-java",
    "text":"Integer.parseInt(\n",
    "u_id":"A0005"
  },
  {
    "timestamp":1443130000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=cast+java",
    "text":"java\n",
    "u_id":"A0001"
  },
  {
    "timestamp":1443130000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=cast+java",
    "text":"cast java\n",
    "u_id":"A0001"
  },
  {
    "timestamp":1445540000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=javax.swing+basic+components",
    "text":"onent\n",
    "u_id":"A0001"
  },
  {
    "timestamp":1445550000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/6095602/how-to-error-handle-java-code",
    "text":" THIS LINE  \n",
    "u_id":"A0001"
  },
  {
    "timestamp":1445550000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/6095602/how-to-error-handle-java-code",
    "text":" THIS LINE  \n",
    "u_id":"A0001"
  },
  {
    "timestamp":1445550000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/6095602/how-to-error-handle-java-code",
    "text":"THIS LINE\n",
    "u_id":"A0001"
  },
  {
    "timestamp":1445550000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/6095602/how-to-error-handle-java-code",
    "text":"THIS LINE\n",
    "u_id":"A0001"
  },
  {
    "timestamp":1445550000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/6095602/how-to-error-handle-java-code",
    "text":"THIS LINE\n",
    "u_id":"A0001"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=3%20partition%20merge%20sort&s=e982ea0a-53ab-42a4-b77c-672f6fc611c7",
    "text":"sort\n",
    "u_id":"A0077"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=3%20partition%20merge%20sort&s=e982ea0a-53ab-42a4-b77c-672f6fc611c7",
    "text":"3 partition merge sort\n",
    "u_id":"A0077"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=merge%20sort",
    "text":"sort\n",
    "u_id":"A0077"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=merge%20sort",
    "text":"merge sort\n",
    "u_id":"A0077"
  },
  {
    "timestamp":1442630000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/6468730/converting-double-to-integer-in-java",
    "text":" \n",
    "u_id":"A0082"
  },
  {
    "timestamp":1442630000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/8819842/best-way-to-format-a-double-value-to-2-decimal-places",
    "text":"%.2f\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1448060000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15983024/how-to-check-if-three-chars-equal-each-other-and-if-they-do-what-do-they-equal",
    "text":"ould\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1448060000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15983024/how-to-check-if-three-chars-equal-each-other-and-if-they-do-what-do-they-equal",
    "text":"ould\n",
    "u_id":"A0082"
  },
  {
    "timestamp":1441270000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15711442/java-using-accessor-and-mutator-methods",
    "text":"     \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1441270000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15711442/java-using-accessor-and-mutator-methods",
    "text":"{ \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1444100000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5383983/java-how-to-update-jlist-once-jframe-has-been-loaded",
    "text":"der to call the code above. The code is supposed to get contact names associated to that account and populate them into the JList. This does not happen. The Jlist stays blank, i debugged and the vector temp does get 3 values and stores them into the new jlist, the problem is, JList does not refresh. \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":" \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":" \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":"show 7 more comments \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":"show 7 more comments \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":"show 7 more comments \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":"show 7 more comments \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":"show 7 more comments \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":"show 7 more comments \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":"activeoldestvotes\n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":"active\n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":"active\n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":"active\n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":"active\n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":"active\n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":"active\n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":"active\n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":"active\n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":" \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":" \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":" \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":" up vote\n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":" up vote\n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":" \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":" \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":" \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":" \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":" \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":" \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":" \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":" \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":" \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":" move Card key = new Card(0, \",\"); inside the for cycle. Like this:\n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":" move Card key = new Card(0, \",\"); inside the for cycle. Like this:\n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":" \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":" \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":" \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":" \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":" move Card key = new Card(0, \",\"); inside the for cycle. Like this:\n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":" move Card key = new Card(0, \",\"); inside the for cycle. Like this:\n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":" \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445930000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23503921/java-insertion-sort-with-an-array-list-of-objects",
    "text":" \n",
    "u_id":"A0010"
  },
  {
    "timestamp":1445980000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19616972/how-to-add-an-object-to-arraylist-in-java",
    "text":"Data objt = new Data();         Contacts.add(objt.Data(name, address, contact));\n",
    "u_id":"A0010"
  },
  {
    "timestamp":1440730000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=read%20string%20into%20array%20in%20java",
    "text":"java\n",
    "u_id":"A0064"
  },
  {
    "timestamp":1440730000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=read%20string%20into%20array%20in%20java",
    "text":"read string into array in java\n",
    "u_id":"A0064"
  },
  {
    "timestamp":1440730000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=read%20string%20into%20array%20in%20java",
    "text":"read string into array in java\n",
    "u_id":"A0064"
  },
  {
    "timestamp":1440780000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12885118/using-java-delimiters-to-match-any-one-character",
    "text":" \n",
    "u_id":"A0064"
  },
  {
    "timestamp":1440780000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12885118/using-java-delimiters-to-match-any-one-character",
    "text":" \n",
    "u_id":"A0064"
  },
  {
    "timestamp":1445020000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5152649/java-convert-mouseevent-to-actionevent",
    "text":"e = new ActionEvent(me.getSource(), me.getID(), me.paramString());\n",
    "u_id":"A0022"
  },
  {
    "timestamp":1444170000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5477241/swing-java-how-to-use-the-gettext-and-settext-string-properly",
    "text":"import javax.swing.JLabel;\n",
    "u_id":"A0050"
  },
  {
    "timestamp":1448050000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/8172420/how-to-convert-a-char-to-a-string-in-java",
    "text":"Character.toString(ch);\n",
    "u_id":"A0050"
  },
  {
    "timestamp":1443060000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=result%20+=%204%20-%20j&s=f3a358db-1ca1-47bd-bfee-89ac519fb973",
    "text":"j\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1443060000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=result%20+=%204%20-%20j&s=f3a358db-1ca1-47bd-bfee-89ac519fb973",
    "text":"result  = 4 - j\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1443590000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12884972/swing-changing-the-content-of-a-panel-using-updateui",
    "text":"updateUI()\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1444600000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=initializing+a+Color+object+in+java",
    "text":"java\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1444600000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=initializing+a+Color+object+in+java",
    "text":"initializing a Color object in java\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10638549/3-way-mergesort",
    "text":"int[] data)\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10638549/3-way-mergesort",
    "text":"mergesort\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1444960000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5977800/splitting-an-array",
    "text":"unt is 3\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1444960000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5977800/splitting-an-array",
    "text":"ant to end up w\n",
    "u_id":"A0061"
  },
  {
    "timestamp":1443070000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=how%20do%20you%20add%20a%20scroll%20pane%20to%20a%20text%20area&s=901902e7-1f6d-4897-a5bd-d4394fdcf6b8",
    "text":"add a scroll pane to a text area\n",
    "u_id":"A0021"
  },
  {
    "timestamp":1441340000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/17986220/how-to-instantiate-an-object-in-java",
    "text":"But that doesn't really make sense, your Sample method always returns 3 . \n",
    "u_id":"A0046"
  },
  {
    "timestamp":1442540000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19289662/how-do-i-get-a-switch-statement-to-loop-back-into-a-menu",
    "text":" menu = true;\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1443130000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14569138/java-why-label-setbackgroundcolor-doesnt-work",
    "text":" \n",
    "u_id":"A0046"
  },
  {
    "timestamp":1443290000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?page=3&tab=relevance&q=in.hasnextdouble",
    "text":" votes\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1443290000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19209411/how-to-read-and-add-only-numbers-to-array-from-a-text-file/19209458#19209458",
    "text":"(in.hasNextDouble()) {                     Double f = in.nextDouble();\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1443320000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=makeCenterPanel",
    "text":"makeCenterPanel\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1443320000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=makeCenterPanel",
    "text":"makeCenterPanel\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1444080000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2901720/java-detect-clicked-buttons",
    "text":"getSource\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1444090000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/7512999/how-to-check-jtextfield-text-to-string",
    "text":"  if(text.equals(compareTo)) {\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1444580000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=in.nextDouble()",
    "text":")\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1444580000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=in.nextDouble()",
    "text":"in.nextDouble()\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1444600000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=.this%28%29",
    "text":")\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1444600000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=.this%28%29",
    "text":".this()\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1444610000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/3695230/how-to-use-java-string-format-in-scala",
    "text":" am trying to use a .format method of a string. But if I place %1, %2, etc. in the string, java.util.UnknownFormatConversionException is thrown pointing to a confusing Java source code piece:\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1444670000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=call%20toString%20from%20abstract%20method",
    "text":"from\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1444670000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=call%20toString%20from%20abstract%20method",
    "text":"call toString from abstract method\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1444750000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5234117/how-to-drop-columns-by-name-in-a-data-frame",
    "text":"subset\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1446830000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15689097/how-do-you-recursively-count-the-number-of-negative-numbers-in-an-array-java",
    "text":"Start by implementing it for an array with 0 elemtents. The for an array of 1 element. The for an array of more,usign the previous results...\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1446830000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15689097/how-do-you-recursively-count-the-number-of-negative-numbers-in-an-array-java",
    "text":"Start by implementing it for an array with 0 elemtents. The for an array of 1 element. The for an array of more,usign the previous results...\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1446830000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15689097/how-do-you-recursively-count-the-number-of-negative-numbers-in-an-array-java",
    "text":"Start by implementing it for an array with 0 elemtents. The for an array of 1 element. The for an array of more,usign the previous results...\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1446830000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15689097/how-do-you-recursively-count-the-number-of-negative-numbers-in-an-array-java",
    "text":" 0\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1446830000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15689097/how-do-you-recursively-count-the-number-of-negative-numbers-in-an-array-java",
    "text":"public static int countNegative(double[] numbers, int count){         int i=0;\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1446830000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15689097/how-do-you-recursively-count-the-number-of-negative-numbers-in-an-array-java",
    "text":"        int i=0;         if(numbers[count]<0)\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1446830000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15689097/how-do-you-recursively-count-the-number-of-negative-numbers-in-an-array-java",
    "text":"0 elements):\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1446830000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15689097/how-do-you-recursively-count-the-number-of-negative-numbers-in-an-array-java",
    "text":"public static int countNegative(double[] numbers, int count){         int i=0;\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1446830000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15689097/how-do-you-recursively-count-the-number-of-negative-numbers-in-an-array-java",
    "text":"public static int countNegative(double[] numbers, int count){         int i=0;\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1446830000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15689097/how-do-you-recursively-count-the-number-of-negative-numbers-in-an-array-java",
    "text":"This is my most recent attempt at countNegative. It just returns 99 (I have the array initialized with 100 elements):\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1448140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15141678/what-does-a-diamond-sign-signify-in-uml-class-diagrams",
    "text":"as usages of both of these two kinds of diagrams.I want to understand what does the diamond signify in the second case and which one of these two gives a stronger association between Customer and Order. Is the Customer class responsible for the lifecycle of Order class in either of the two cases ? .\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1448140000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/15141678/what-does-a-diamond-sign-signify-in-uml-class-diagrams",
    "text":" Is the Customer class responsible for the lifecycle of Order class in either of the two cases ? .\n",
    "u_id":"A0046"
  },
  {
    "timestamp":1446060000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12838346/possible-exception-if-user-enters-string-instead-of-int",
    "text":"NumberFormatException \n",
    "u_id":"A0057"
  },
  {
    "timestamp":1446060000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12838346/possible-exception-if-user-enters-string-instead-of-int",
    "text":" \n",
    "u_id":"A0057"
  },
  {
    "timestamp":1446060000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12838346/possible-exception-if-user-enters-string-instead-of-int",
    "text":" \n",
    "u_id":"A0057"
  },
  {
    "timestamp":1446060000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14475556/how-to-sort-arraylist-of-objects",
    "text":"int compare(Team o1, Team o2) {         if (o1.getPoints() > o2.getPoints())\n",
    "u_id":"A0057"
  },
  {
    "timestamp":1446060000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14475556/how-to-sort-arraylist-of-objects",
    "text":"int compare(Team o1, Team o2) {         if (o1.getPoints() > o2.getPoints())\n",
    "u_id":"A0057"
  },
  {
    "timestamp":1446840000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19239669/try-to-get-the-sum-of-even-numbers-in-an-array-using-recursion",
    "text":"   return 1 + countE(arr, head + 1);     } else {\n",
    "u_id":"A0057"
  },
  {
    "timestamp":1446840000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19239669/try-to-get-the-sum-of-even-numbers-in-an-array-using-recursion",
    "text":"   return 1 + countE(arr, head + 1);     } else {\n",
    "u_id":"A0057"
  },
  {
    "timestamp":1446840000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19239669/try-to-get-the-sum-of-even-numbers-in-an-array-using-recursion",
    "text":" return 1 + countE(arr, head + 1);\n",
    "u_id":"A0057"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=clearing+array+method+java",
    "text":"learin\n",
    "u_id":"A0024"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=clearing+array+method+java",
    "text":"learing\n",
    "u_id":"A0024"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=emptying+array+method+java",
    "text":"ing\n",
    "u_id":"A0024"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=how+to+empty+array+method+java",
    "text":"method\n",
    "u_id":"A0024"
  },
  {
    "timestamp":1448030000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/26699089/infix-to-postfix-using-stacks-java",
    "text":"        case '-':             return !(op2 == '+' || op2 == '-');\n",
    "u_id":"A0049"
  },
  {
    "timestamp":1448030000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/26699089/infix-to-postfix-using-stacks-java",
    "text":"        case '-':             return !(op2 == '+' || op2 == '-');\n",
    "u_id":"A0049"
  },
  {
    "timestamp":1448030000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/26699089/infix-to-postfix-using-stacks-java",
    "text":"        case '-':             return !(op2 == '+' || op2 == '-');\n",
    "u_id":"A0049"
  },
  {
    "timestamp":1448030000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/26699089/infix-to-postfix-using-stacks-java",
    "text":"    switch (op1)     {\n",
    "u_id":"A0049"
  },
  {
    "timestamp":1448030000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/26699089/infix-to-postfix-using-stacks-java",
    "text":"    switch (op1)     {\n",
    "u_id":"A0049"
  },
  {
    "timestamp":1444860000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12208574/using-addmouselistener-and-paintcomponent-for-jpanel",
    "text":"(mouseListener); }\n",
    "u_id":"A0052"
  },
  {
    "timestamp":1444860000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12208574/using-addmouselistener-and-paintcomponent-for-jpanel",
    "text":"(mouseListener); }\n",
    "u_id":"A0052"
  },
  {
    "timestamp":1444860000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12208574/using-addmouselistener-and-paintcomponent-for-jpanel",
    "text":"protected MouseListener createMouseListener() {     MouseListener l = new MouseListener() {\n",
    "u_id":"A0052"
  },
  {
    "timestamp":1444860000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/12208574/using-addmouselistener-and-paintcomponent-for-jpanel",
    "text":"protected MouseListener createMouseListener() {     MouseListener l = new MouseListener() {\n",
    "u_id":"A0052"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10638549/3-way-mergesort",
    "text":"public static void mergesort(int[] data) {     int elements = data.length - 1;\n",
    "u_id":"A0052"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10638549/3-way-mergesort",
    "text":"void merge(int arr1[], int arr2[]) {\n",
    "u_id":"A0052"
  },
  {
    "timestamp":1444960000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10638549/3-way-mergesort",
    "text":"3-way mergesort \n",
    "u_id":"A0052"
  },
  {
    "timestamp":1444960000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10638549/3-way-mergesort",
    "text":"3-way mergesort \n",
    "u_id":"A0052"
  },
  {
    "timestamp":1444960000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10638549/3-way-mergesort",
    "text":"3-way mergesort \n",
    "u_id":"A0052"
  },
  {
    "timestamp":1440720000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9367554/finding-the-smallest-integer-based-on-input",
    "text":" \n",
    "u_id":"B0012"
  },
  {
    "timestamp":1440720000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9367554/finding-the-smallest-integer-based-on-input",
    "text":" \n",
    "u_id":"B0012"
  },
  {
    "timestamp":1440800000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9367554/finding-the-smallest-integer-based-on-input",
    "text":"import java.util.Scanner; \n",
    "u_id":"B0012"
  },
  {
    "timestamp":1440800000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/22848723/recursion-computing-sum-of-positive-integers",
    "text":"{             total = numbers[count-1] + computeSumPositive(numbers, count -1); \n",
    "u_id":"B0012"
  },
  {
    "timestamp":1440800000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/22848723/recursion-computing-sum-of-positive-integers",
    "text":"{             total = numbers[count-1] + computeSumPositive(numbers, count -1); \n",
    "u_id":"B0012"
  },
  {
    "timestamp":1442620000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14678523/formatting-a-decimal-within-a-tostring-method",
    "text":"ding the appropriateness of BigDecimal, if you are dealing with money, which you are, where precision is required, use BigDecimal. \n",
    "u_id":"B0012"
  },
  {
    "timestamp":1442620000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/14678523/formatting-a-decimal-within-a-tostring-method",
    "text":"ding the appropriateness of BigDecimal, if you are dealing with money, which you are, where precision is required, use BigDecimal. \n",
    "u_id":"B0012"
  },
  {
    "timestamp":1442620000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/13791409/java-format-double-value-as-dollar-amount",
    "text":"NumberFormat formatter = NumberFormat.getCurrencyInstance();\n",
    "u_id":"B0012"
  },
  {
    "timestamp":1444960000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9355061/how-to-use-canvas-to-draw-multiple-rectangles-based-on-user-input",
    "text":"     \n",
    "u_id":"B0020"
  },
  {
    "timestamp":1444970000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9355061/how-to-use-canvas-to-draw-multiple-rectangles-based-on-user-input",
    "text":"anel\n",
    "u_id":"B0020"
  },
  {
    "timestamp":1444970000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9355061/how-to-use-canvas-to-draw-multiple-rectangles-based-on-user-input",
    "text":"xEnd-xStart\n",
    "u_id":"B0020"
  },
  {
    "timestamp":1444980000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9355061/how-to-use-canvas-to-draw-multiple-rectangles-based-on-user-input",
    "text":"pointListen\n",
    "u_id":"B0020"
  },
  {
    "timestamp":1445030000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9355061/how-to-use-canvas-to-draw-multiple-rectangles-based-on-user-input",
    "text":"public WholePanel()\n",
    "u_id":"B0020"
  },
  {
    "timestamp":1445030000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9355061/how-to-use-canvas-to-draw-multiple-rectangles-based-on-user-input",
    "text":"private ArrayList<Rect> rectList; private Color currentColor;\n",
    "u_id":"B0020"
  },
  {
    "timestamp":1445030000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9355061/how-to-use-canvas-to-draw-multiple-rectangles-based-on-user-input",
    "text":"private ArrayList<Rect> rectList; private Color currentColor;\n",
    "u_id":"B0020"
  },
  {
    "timestamp":1445030000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9355061/how-to-use-canvas-to-draw-multiple-rectangles-based-on-user-input",
    "text":"vate class Canvas extends JP\n",
    "u_id":"B0020"
  },
  {
    "timestamp":1445030000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9355061/how-to-use-canvas-to-draw-multiple-rectangles-based-on-user-input",
    "text":"vate ArrayList<Rect> rectList\n",
    "u_id":"B0020"
  },
  {
    "timestamp":1445490000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/487258/plain-english-explanation-of-big-o",
    "text":"Big-O notation is a relative representation of the complexity of an algorithm.\n",
    "u_id":"B0020"
  },
  {
    "timestamp":1445490000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/487258/plain-english-explanation-of-big-o",
    "text":"odes t\n",
    "u_id":"B0020"
  },
  {
    "timestamp":1445490000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/487258/plain-english-explanation-of-big-o",
    "text":"odes t\n",
    "u_id":"B0020"
  },
  {
    "timestamp":1445500000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/6799731/jtabbedpane-changelistener",
    "text":"1\n",
    "u_id":"B0020"
  },
  {
    "timestamp":1440770000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=how+to+get+more+than+one+input&s=41d9ad62-8c41-4a5f-bbd0-e816e38c7dbf",
    "text":"input\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=how+to+get+more+than+one+input&s=41d9ad62-8c41-4a5f-bbd0-e816e38c7dbf",
    "text":"how to get more than one input\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=how+to+get+more+than+one+input&s=41d9ad62-8c41-4a5f-bbd0-e816e38c7dbf",
    "text":"how to get more than one input\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=how+to+get+more+than+one+input&s=41d9ad62-8c41-4a5f-bbd0-e816e38c7dbf",
    "text":"how to get more than one input\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440770000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/19109390/how-do-i-pass-variables-between-methods-in-java",
    "text":"How do I pass variables between methods in java?\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440780000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=passing%20variables%20to%20main%20method&s=e7d79f1f-93a5-448e-8027-a7a0814530a3",
    "text":"method\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440780000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=passing%20variables%20to%20main%20method&s=e7d79f1f-93a5-448e-8027-a7a0814530a3",
    "text":"passing variables to main method\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440780000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=passing%20variables%20to%20main%20method&s=e7d79f1f-93a5-448e-8027-a7a0814530a3",
    "text":"passing variables to main method\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1440780000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=passing%20variables%20to%20main%20method&s=e7d79f1f-93a5-448e-8027-a7a0814530a3",
    "text":"passing variables to main method\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1444100000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9212155/java-boxlayout-panels-alignment",
    "text":"NMENT );//0.0    b.setAlignmentX( Component.LEFT_ALIGNMENT );//0.0\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1444180000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10675064/find-duplicates-of-a-vector-and-delete-preserving-the-order-of-parallel-vectors",
    "text":"Stack Exchange Inbox Reputation and Badges sign up log in tour help  stack overflow careers   \n",
    "u_id":"A0080"
  },
  {
    "timestamp":1444370000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/21174997/how-to-add-mouselistener-to-item-on-java-swing-canvas",
    "text":" \n",
    "u_id":"A0080"
  },
  {
    "timestamp":1444370000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/21174997/how-to-add-mouselistener-to-item-on-java-swing-canvas",
    "text":" \n",
    "u_id":"A0080"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=merge+sort+examples++arraylisr+java",
    "text":"examples  \n",
    "u_id":"A0080"
  },
  {
    "timestamp":1445040000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/26638620/java-add-rectangles-to-arraylist-and-then-draw-them",
    "text":"  Don't make Shapes a JPanel. Also take out its paintComponent method.\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1445040000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/26638620/java-add-rectangles-to-arraylist-and-then-draw-them",
    "text":"  Don't make Shapes a JPanel. Also take out its paintComponent method.\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1445450000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9441422/how-to-make-a-jpanel-inside-a-jframe-fill-the-whole-window",
    "text":"et BorderLayout in frame. Add panel in frame with BorderLayout.CENT\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1445450000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9441422/how-to-make-a-jpanel-inside-a-jframe-fill-the-whole-window",
    "text":"et BorderLayout in frame. Add panel in frame with BorderLayout.CENT\n",
    "u_id":"A0080"
  },
  {
    "timestamp":1441410000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/22977705/java-accessor-method-mutator-method",
    "text":"accessor\n",
    "u_id":"B0027"
  },
  {
    "timestamp":1441410000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/22977705/java-accessor-method-mutator-method",
    "text":"Any method that changes an object's state is properly a mutator. As you are changing the dimensions (through the swap) it is a mutation. These would be accessor methods given your class definition, \n",
    "u_id":"B0027"
  },
  {
    "timestamp":1441410000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/22977705/java-accessor-method-mutator-method",
    "text":"Any method that changes an object's state is properly a mutator. As you are changing the dimensions (through the swap) it is a mutation. These would be accessor methods given your class definition, \n",
    "u_id":"B0027"
  },
  {
    "timestamp":1441410000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/22977705/java-accessor-method-mutator-method",
    "text":"See this discussion of the meaning of accessor methods. The general opinion is that they do not modify state. If you are rotating the object, you are modifying its state and rotate is mutating the object. \n",
    "u_id":"B0027"
  },
  {
    "timestamp":1441410000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/22977705/java-accessor-method-mutator-method",
    "text":"See this discussion of the meaning of accessor methods. The general opinion is that they do not modify state. If you are rotating the object, you are modifying its state and rotate is mutating the object. \n",
    "u_id":"B0027"
  },
  {
    "timestamp":1442540000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2534733/java-protected-classes",
    "text":"be\n",
    "u_id":"B0027"
  },
  {
    "timestamp":1442540000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2534733/java-protected-classes",
    "text":"I'd like to be able to have two protected classes in my package. That is, I do not want files outside of my package to see them as visible - they will be for internal use within the package only. \n",
    "u_id":"B0027"
  },
  {
    "timestamp":1442540000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2534733/java-protected-classes",
    "text":"I'd like to be able to have two protected classes in my package. That is, I do not want files outside of my package to see them as visible - they will be for internal use within the package only. \n",
    "u_id":"B0027"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10638549/3-way-mergesort",
    "text":" \n",
    "u_id":"B0027"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10638549/3-way-mergesort",
    "text":"What I've done is first of all split the array in 3 parts depending the circumstances, after that I sort the 3 parts of the array and later I try merging the first 2 parts and then the combined part with the last part. \n",
    "u_id":"B0027"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10638549/3-way-mergesort",
    "text":"What I've done is first of all split the array in 3 parts depending the circumstances, after that I sort the 3 parts of the array and later I try merging the first 2 parts and then the combined part with the last part. \n",
    "u_id":"B0027"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10667884/3-partition-mergesort",
    "text":"doing\n",
    "u_id":"B0027"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10667884/3-partition-mergesort",
    "text":"That was the exact question from the professor. Problem is I have found no such thing as a 3-way mergesort I only know of a 3-way quicksort so I thought that he probably meant to take an array, split it into 3 parts and then mergesort those 3 parts together and I'm doing this by mergesorting the first 2 parts together and then mergesorting the combined part with the 3rd part. \n",
    "u_id":"B0027"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/10667884/3-partition-mergesort",
    "text":"That was the exact question from the professor. Problem is I have found no such thing as a 3-way mergesort I only know of a 3-way quicksort so I thought that he probably meant to take an array, split it into 3 parts and then mergesort those 3 parts together and I'm doing this by mergesorting the first 2 parts together and then mergesorting the combined part with the 3rd part. \n",
    "u_id":"B0027"
  },
  {
    "timestamp":1444960000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/20389890/generating-a-random-number-between-1-and-10-java",
    "text":"random.nextInt(\n",
    "u_id":"B0027"
  },
  {
    "timestamp":1444960000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/20389890/generating-a-random-number-between-1-and-10-java",
    "text":"random.nextInt(ma\n",
    "u_id":"B0027"
  },
  {
    "timestamp":1444960000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/20389890/generating-a-random-number-between-1-and-10-java",
    "text":"random.nextInt(max - min + 1) + min\n",
    "u_id":"B0027"
  },
  {
    "timestamp":1444960000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/20389890/generating-a-random-number-between-1-and-10-java",
    "text":"random.nextInt(max - min + 1) + min\n",
    "u_id":"B0027"
  },
  {
    "timestamp":1446510000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2885173/how-to-create-a-file-and-write-to-a-file-in-java",
    "text":"tput\n",
    "u_id":"B0027"
  },
  {
    "timestamp":1446510000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2885173/how-to-create-a-file-and-write-to-a-file-in-java",
    "text":"he-file-nam\n",
    "u_id":"B0027"
  },
  {
    "timestamp":1446510000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2885173/how-to-create-a-file-and-write-to-a-file-in-java",
    "text":"he-file-nam\n",
    "u_id":"B0027"
  },
  {
    "timestamp":1446510000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2885173/how-to-create-a-file-and-write-to-a-file-in-java",
    "text":"the-file-name\n",
    "u_id":"B0027"
  },
  {
    "timestamp":1446510000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2885173/how-to-create-a-file-and-write-to-a-file-in-java",
    "text":"file\n",
    "u_id":"B0027"
  },
  {
    "timestamp":1446510000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2885173/how-to-create-a-file-and-write-to-a-file-in-java",
    "text":"file\n",
    "u_id":"B0027"
  },
  {
    "timestamp":1446510000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2885173/how-to-create-a-file-and-write-to-a-file-in-java",
    "text":"dataToWrite\n",
    "u_id":"B0027"
  },
  {
    "timestamp":1446510000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2885173/how-to-create-a-file-and-write-to-a-file-in-java",
    "text":"dataToWrite\n",
    "u_id":"B0027"
  },
  {
    "timestamp":1446160000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4064633/string-comparison-in-java",
    "text":".compareToIgnoreCase ()\n",
    "u_id":"A0018"
  },
  {
    "timestamp":1442640000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/5895338/java-format-double-with-decimals/5895513#5895513",
    "text":"N\n",
    "u_id":"B0018"
  },
  {
    "timestamp":1440730000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4011002/java-eclipse-on-macosx-where-is-the-src-zip",
    "text":"activeoldestvotes\n",
    "u_id":"B0024"
  },
  {
    "timestamp":1440730000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4011002/java-eclipse-on-macosx-where-is-the-src-zip",
    "text":"activeoldestvotes\n",
    "u_id":"B0024"
  },
  {
    "timestamp":1440730000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/4011002/java-eclipse-on-macosx-where-is-the-src-zip",
    "text":"  \n",
    "u_id":"B0024"
  },
  {
    "timestamp":1442620000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/1197634/java-error-implicit-super-constructor-is-undefined-for-default-constructor",
    "text":"public ACSubClass() {     super();\n",
    "u_id":"B0024"
  },
  {
    "timestamp":1441940000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=how+to+converse+down+case+to+up+case",
    "text":"converse down case to up case\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1442600000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/2390063/what-does-public-static-void-mean-in-java",
    "text":"method is associated with the class\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1442610000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23735970/superclass-package-vs-class",
    "text":"ifferent classes in it and\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1442610000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23735970/superclass-package-vs-class",
    "text":"ne of those \n",
    "u_id":"A0008"
  },
  {
    "timestamp":1442610000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23735970/superclass-package-vs-class",
    "text":"sses. Is this correct? If java.utilpackage has different classes in it and one of those classes is Random cl\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1442610000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23735970/superclass-package-vs-class",
    "text":"es Random class have the acm.util packages in it? Are packages extensions of classes?\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1442610000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/23735970/superclass-package-vs-class",
    "text":"es Random class have the acm.util packages in it? Are packages extensions of classes?\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1442630000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=number%20format%20persentage&s=cd5d7e84-df17-4d7b-b91a-9af58d0dc67b",
    "text":"persentage\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/11461607/cant-start-eclipse-java-was-started-but-returned-exit-code-13",
    "text":"C:Progra\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1444950000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/11461607/cant-start-eclipse-java-was-started-but-returned-exit-code-13",
    "text":"C:Progra\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1445020000000,
    "operation":"select",
    "url":"http://stackoverflow.com/search?q=how%20to%20transfer%20int%20to%20color",
    "text":"how to transfer int to color\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1446100000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/8394252/what-is-the-point-of-using-abstract-methods",
    "text":"instantiated,\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1446100000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/8394252/what-is-the-point-of-using-abstract-methods",
    "text":"instantiated\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1446790000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9441094/why-it-is-mandatory-to-use-throws-ioexception",
    "text":"mandatory\n",
    "u_id":"A0008"
  },
  {
    "timestamp":1446790000000,
    "operation":"select",
    "url":"http://stackoverflow.com/questions/9441094/why-it-is-mandatory-to-use-throws-ioexception",
    "text":"mandatory\n",
    "u_id":"A0008"
  }
]